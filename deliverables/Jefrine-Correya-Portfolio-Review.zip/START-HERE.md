# Clean native quality repair — current source

Live homepage: https://jefrine-correya-portfolio.vercel.app
Native video: https://jefrine-correya-portfolio.vercel.app/media/cybersecurity-native-glass-1080p60.mp4
Branch: fix/native-glass-quality
HEAD: cc876aef7d1cee4567393e999cb110ee3630d34b
Implementation: 80963c14eaf1a3b2f33f80fbbc1423e5e5a16bb3
Deployment: dpl_HzgvNUXu5cigYeNmJWcPV5Zpgo7N — Ready

The owner approved native re-export after the prior video-only cleanup created artifacts. This version uses the existing original scene/camera/environment and approved 18s pacing, fresh 2x/3x genuine browser captures and native 1920×1080/60fps frames. It has zero editorial bottom cards/title/index planes. No CV inpaint/upscale/optical-flow repair. Older report fine text remains source-limited; no invented dashboard data.

## Packaging

Current React implementation, original PDFs, fonts, ordinary website image assets, rendering/capture code and lossless native textures are included. MP4 binaries and the separately delivered offline HTML are not duplicated in this ZIP. Unused legacy root assets are omitted only from this delivery archive; authored originals and Git history remain intact in the working repository. The older Git bundle is historical, not this repair branch.

Restore video binaries before running a complete website build:

    python review/restore-videos.py
    cd jefrine-portfolio
    npm ci
    npm run dev

The new native MP4 is also supplied as a direct downloadable deliverable. Read docs/NATIVE-QUALITY-REPAIR.md for rendering/QA/limitations. Normal rerender uses the supplied native textures, npm run showreel:studio, then node scripts/native-clean/render.mjs. FFmpeg and Playwright Chromium required; no capture dependencies needed unless intentionally recapturing.

Native film: 18s, 1080 frames, 60fps, H264 High4.2, BT709, faststart, no audio; 11,641,244 bytes. Local and public full suites each pass86 /skip2 /no failures/flaky. Original site/domain/DNS/main/PDF bytes/contact-provider setup untouched. No remote push/PR/merge. Physical M2/Safari/field-CWV certification not claimed.
