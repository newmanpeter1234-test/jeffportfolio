import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: { host: '0.0.0.0', port: 5173, strictPort: true, allowedHosts: ['.e2b.app', 'localhost'] },
  preview: { host: '0.0.0.0', port: 4173, strictPort: true, allowedHosts: ['.e2b.app', 'localhost'] },
  build: {
    target: 'es2022', sourcemap: false,
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (id.includes('/node_modules/three/')) return 'vendor-webgl';
          if (id.includes('/node_modules/gsap/')) return 'vendor-motion';
        },
      },
    },
  },
});
