"""Capture-only harness for the pinned, public ASTRA UI. No threat generation."""
import os, sys, secrets
from pathlib import Path
source = Path(os.environ.get('ASTRA_SOURCE', str(Path.home() / '.cache/hero-projects/astra'))).resolve()
sys.path.insert(0, str(source))
import app as upstream
upstream.app.config['SECRET_KEY'] = secrets.token_hex(32)
# Keep the original built-in sample rows; do not manufacture or stream events.
upstream.data_gen.generate_threat_data = lambda: None
@upstream.app.after_request
def local_socket(response):
    if upstream.request.path == '/static/main.js':
        response.direct_passthrough = False
        response.set_data(response.get_data().replace(b"io('http://localhost:5020')", b'io()'))
    return response
if __name__ == '__main__':
    upstream.socketio.run(upstream.app, host='0.0.0.0', port=5020, debug=False)
