// Offline asset production only. Requires Playwright, FFmpeg, pinned public ASTRA source.
import { chromium } from 'playwright';
import { mkdir, writeFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { homedir } from 'node:os';
const source = process.env.ASTRA_SOURCE || path.join(homedir(), '.cache/hero-projects/astra');
const upstreamCommit = execFileSync('git', ['-C', source, 'rev-parse', 'HEAD'], {encoding:'utf8'}).trim();
if (upstreamCommit !== 'ffa45993badc72b9683beb6e2c8a79fe00a3248d' || execFileSync('git', ['-C', source, 'status', '--porcelain', '--untracked-files=no'], {encoding:'utf8'}).trim()) throw new Error('Capture requires the clean, pinned ASTRA source described in docs/HERO-UPGRADE.md.');
const scratch = path.resolve('.cache/hero-capture');
await mkdir(scratch, { recursive: true });
await mkdir('public/media', { recursive: true });
const browser = await chromium.launch({ args: ['--no-sandbox'] });
const context = await browser.newContext({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 1, locale: 'en-GB', timezoneId: 'UTC', recordVideo: { dir: scratch, size: { width: 1280, height: 800 } } });
const page = await context.newPage();
const errors = [];
page.on('pageerror', error => errors.push(error.message));
await page.route('**/static/globe.js', route => route.fulfill({ contentType:'application/javascript', body:'/* Offscreen decorative globe omitted in capture harness. */' }));
await page.goto('http://localhost:5020', { waitUntil: 'networkidle' });
await page.locator('#threatTable tr').nth(1).waitFor();
await page.addStyleTag({ content: `
 body{padding-bottom:800px!important;scroll-behavior:smooth}
 .navbar{position:fixed;top:0;left:0;right:0;z-index:1040;background:#030c10!important}
 #network{visibility:hidden}
 #td-confidence{visibility:hidden}
 tr:has(#td-confidence){display:none}
 #navbarNav>.d-flex{visibility:hidden}
 #capture-label{position:fixed;left:30px;bottom:22px;z-index:1099;border:1px solid #3d645c;background:#07130ff5;color:#c5f58a;padding:9px 14px;font:11px monospace;letter-spacing:1px;pointer-events:none}
 #capture-cursor{position:fixed;left:0;top:0;width:17px;height:22px;z-index:1100;pointer-events:none;filter:drop-shadow(0 2px 3px #000)}
 *{cursor:none!important}
` });
await page.locator('small').filter({ hasText: 'Model accuracy:' }).evaluateAll(elements => elements.forEach(element => { element.style.visibility = 'hidden'; }));
await page.evaluate(() => {
 const label = document.createElement('div'); label.id = 'capture-label'; label.textContent = 'LOCAL DEMO / EXISTING SAMPLE ALERTS'; document.body.append(label);
 const cursor = document.createElement('div'); cursor.id = 'capture-cursor'; cursor.innerHTML = '<svg viewBox="0 0 17 22"><path d="M2 1 15 14 9 14 6 20Z" fill="#e5ffd1" stroke="#11251b" stroke-width="1.5" stroke-linejoin="round"/></svg>'; document.body.append(cursor);
 document.addEventListener('mousemove', event => { cursor.style.transform = `translate(${event.clientX}px,${event.clientY}px)`; });
 document.addEventListener('mousedown', () => { cursor.style.opacity = '.55'; });
 document.addEventListener('mouseup', () => { cursor.style.opacity = '1'; });
});
await page.locator('a[href="#threats"]').click();
await page.evaluate(() => window.scrollTo({ top: document.getElementById('threats').offsetTop - 150, behavior: 'instant' }));
await page.waitForTimeout(700);
// Capture the poster before recording the timed action sequence.
await page.locator('#threatTable button').first().click();
await page.locator('#threatDetailsModal.show').waitFor();
await page.waitForTimeout(400);
await page.screenshot({ path: path.join(scratch, 'poster.png') });
await page.locator('#threatDetailsModal .modal-content').screenshot({ path: path.join(scratch, 'mobile-poster.png') });
await page.getByRole('button', { name: 'Close Investigation', exact: true }).click();
await page.waitForTimeout(400);
await page.mouse.move(290, 277);
const start = Date.now();
const hold = ms => page.waitForTimeout(ms);
await hold(1300);
const detail = page.locator('#threatTable button').first();
const box = await detail.boundingBox();
await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2, { steps: 28 });
await hold(350);
await detail.click();
await page.locator('#threatDetailsModal.show').waitFor();
const opened = (Date.now() - start) / 1000;
await hold(500);
await page.mouse.move(500, 350, { steps: 20 });
await hold(2200);
const close = page.getByRole('button', { name: 'Close Investigation', exact: true });
const closeBox = await close.boundingBox();
await page.mouse.move(closeBox.x + closeBox.width / 2, closeBox.y + closeBox.height / 2, { steps: 25 });
await hold(250);
await close.click();
const closed = (Date.now() - start) / 1000;
await hold(450);
await page.mouse.move(290, 277, { steps: 25 });
const remaining = 10800 - (Date.now() - start);
if (remaining > 0) await hold(remaining);
const seconds = (Date.now() - start) / 1000;
const video = page.video();
await page.close(); await context.close();
const raw = path.join(scratch, 'astra-raw.webm'); await video.saveAs(raw);
await browser.close();
const duration = Number(execFileSync('ffprobe', ['-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',raw], { encoding:'utf8' }).trim());
const offset = Math.max(0, duration - seconds - .10);
// One gentle 1.5% breathing camera move. First/last framing matches exactly.
execFileSync('ffmpeg', ['-y','-ss',String(offset),'-i',raw,'-t','10.8','-an','-vf',`trim=duration=${seconds},setpts=(PTS-STARTPTS)*${10.8/seconds},fps=30,scale=1280:800,zoompan=z='1.015+0.015*sin(on*PI/324)*sin(on*PI/324)':x='iw/2-iw/zoom/2':y='ih/2-ih/zoom/2':d=1:s=1152x720:fps=30,format=yuv420p`,'-c:v','libx264','-preset','slow','-crf','24','-profile:v','main','-level','3.1','-movflags','+faststart','public/media/astra-hero.mp4'], { stdio:'ignore' });
execFileSync('ffmpeg', ['-y','-i',path.join(scratch,'poster.png'),'-vf','scale=1152:720','-quality','84','public/images/astra-hero-poster.webp'], { stdio:'ignore' });
execFileSync('ffmpeg', ['-y','-i',path.join(scratch,'mobile-poster.png'),'-vf','scale=-2:400,pad=704:440:(ow-iw)/2:(oh-ih)/2:color=0x05100b','-quality','76','public/images/astra-hero-mobile.webp'], { stdio:'ignore' });
const manifest = { sourceRepository:'https://github.com/jeff-1217/ASTRA-Monitor', sourceCommit:upstreamCommit, duration:10.8, format:'H.264 Main / yuv420p / 1152x720 / 30fps / no audio / faststart', interactions:['Open existing THR-10234 sample row','Inspect original detail modal','Dismiss using existing Close Investigation control'], captureHarness:['Random telemetry generator paused','Socket URL made same-origin','Unverified accuracy/confidence claims redacted','Demo labels and synchronized pointer added for recording only', 'Offscreen decorative globe and unused status/activation controls omitted for capture'], sourcePageErrors:errors, phases:[{start:0,label:'Review alert'},{start:Number((opened*10.8/seconds).toFixed(2)),label:'Open context'},{start:Number((closed*10.8/seconds).toFixed(2)),label:'Close panel'}] };
await writeFile('src/data/hero-showcase.json', JSON.stringify({duration:10.8,phases:manifest.phases},null,2)+'\n');
await writeFile('public/media/astra-hero.provenance.json',JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify({ rawDuration:duration, capturedDuration:seconds, trimStart:offset, ...manifest },null,2));
