import { chromium } from 'playwright';
import { build } from 'esbuild';
import { writeFile,mkdir } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
await mkdir('.cache/showreel/exports',{recursive:true});
await build({entryPoints:['scripts/showreel/renderer/main.mjs'],bundle:true,format:'esm',target:'es2022',outfile:'.cache/showreel/studio/studio.js'});
const args=['--no-sandbox'];if(process.argv.includes('--software'))args.push('--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader');
const browser=await chromium.launch({args});
try{
 const page=await browser.newPage({viewport:{width:1280,height:720},deviceScaleFactor:1});
 await page.goto('http://localhost:5050/?mode=master&capture=1');await page.waitForFunction(()=>window.__filmReady,undefined,{timeout:90000});
 const data=await page.evaluate(()=>{window.__film.renderAt(39);return window.__film.exportFrame('png');});
 await writeFile('.cache/showreel/exports/poster.png',Buffer.from(data,'base64'));
 execFileSync('ffmpeg',['-y','-i','.cache/showreel/exports/poster.png','-quality','88','public/images/cybersecurity-showreel-poster.webp'],{stdio:'ignore'});
 execFileSync('ffmpeg',['-y','-i','.cache/showreel/exports/poster.png','-vf','scale=704:396','-quality','84','public/images/cybersecurity-showreel-mobile.webp'],{stdio:'ignore'});
 console.log('Rendered genuine eight-project gallery posters from the same scene system at t=39s.');
}finally{await browser.close();}
