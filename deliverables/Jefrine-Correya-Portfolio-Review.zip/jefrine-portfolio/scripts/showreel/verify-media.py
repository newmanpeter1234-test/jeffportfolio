"""Decode every delivered frame; inspect timing/streams/loop and export visual QC samples."""
from pathlib import Path
from PIL import Image, ImageChops, ImageStat, ImageDraw
import subprocess, json, hashlib, math
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'.cache/showreel/final-qc';OUT.mkdir(parents=True,exist_ok=True)
def probe(path):
    return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(path)],text=True))
def exact_read(stream,size):
    data=b''
    while len(data)<size:
        part=stream.read(size-len(data))
        if not part:return data
        data+=part
    return data
results={}
for mode,duration,name in [('master',41,'cybersecurity-showreel.mp4'),('hero',10.8,'cybersecurity-hero-loop.mp4')]:
    path=ROOT/'public/media'/name;meta=probe(path);streams=meta['streams'];video=[s for s in streams if s['codec_type']=='video']
    assert len(video)==1 and not any(s['codec_type']=='audio'for s in streams)
    v=video[0];assert v['codec_name']=='h264' and v['pix_fmt']=='yuv420p' and v['width']==1280 and v['height']==720
    assert abs(float(meta['format']['duration'])-duration)<.04
    assert v['avg_frame_rate']=='30/1'
    body=path.read_bytes();assert body.find(b'moov')<body.find(b'mdat'),'fast-start atom order'
    pipe=subprocess.Popen(['ffmpeg','-v','error','-i',str(path),'-vf','scale=160:90','-f','rawvideo','-pix_fmt','rgb24','pipe:1'],stdout=subprocess.PIPE)
    count=0;means=[];diffs=[];previous=None;first=None;last=None
    while True:
        chunk=exact_read(pipe.stdout,160*90*3)
        if not chunk:break
        assert len(chunk)==160*90*3,'partial decoded frame'
        im=Image.frombytes('RGB',(160,90),chunk);mean=sum(ImageStat.Stat(im).mean)/3
        assert mean>1,f'Blank/unrendered frame {mode}:{count}'
        if previous:diffs.append(sum(ImageStat.Stat(ImageChops.difference(im,previous)).mean)/3)
        if first is None:first=im.copy()
        last=im.copy();previous=im;means.append(mean);count+=1
    assert pipe.wait()==0 and count==round(duration*30),(mode,count)
    seam=sum(ImageStat.Stat(ImageChops.difference(first,last)).mean)/3 if mode=='hero' else None
    if seam is not None:assert seam<3,('Loop seam exceeds tolerance',seam)
    # Sample every half-second from the actual encoded movie, not just the source renderer.
    subprocess.run(['ffmpeg','-y','-v','error','-i',str(path),'-vf','fps=2,scale=640:360','-q:v','2',str(OUT/(mode+'-%03d.jpg'))],check=True)
    images=sorted(OUT.glob(mode+'-*.jpg'))
    for offset in range(0,len(images),16):
        batch=images[offset:offset+16];sheet=Image.new('RGB',(1280,math.ceil(len(batch)/2)*390),(7,12,16));draw=ImageDraw.Draw(sheet)
        for i,file in enumerate(batch):
            x=(i%2)*640;y=(i//2)*390;sheet.paste(Image.open(file),(x,y+25));draw.text((x+12,y+7),f'{mode} / {(offset+i)*.5:.1f}s',fill='white')
        sheet.save(OUT/f'{mode}-review-{offset//16+1}.webp',quality=90,method=4)
    if mode=='master':
        featured=OUT/'featured';featured.mkdir(exist_ok=True)
        film=json.loads((ROOT/'src/data/showreel.json').read_text())
        for project in film['projects']:
            subprocess.run(['ffmpeg','-y','-v','error','-ss',str(project['start']+1.9),'-i',str(path),'-frames:v','1','-q:v','2',str(featured/(project['id']+'.jpg'))],check=True)
    results[mode]={'file':name,'duration':float(meta['format']['duration']),'width':v['width'],'height':v['height'],'fps':30,'decodedFrames':count,'blankFrames':0,'audioStreams':0,'codec':v['codec_name'],'profile':v['profile'],'pixelFormat':v['pix_fmt'],'faststart':True,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'minimumFrameMean':min(means),'maximumAdjacentFrameDifference':max(diffs),'loopSeamMeanAbsolutePixelDifference':seam,'qcSamples':len(images)}
(ROOT/'.cache/showreel/final-media-verification.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
