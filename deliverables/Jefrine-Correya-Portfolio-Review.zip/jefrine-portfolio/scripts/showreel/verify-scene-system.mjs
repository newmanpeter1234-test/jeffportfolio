import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import {createHash} from 'node:crypto';
import * as THREE from 'three';
import { FILM, PROJECTS, projectLayout } from './scene/config.mjs';
import { stateAt, localToWorld, cameraKeys } from './scene/timeline.mjs';
assert.equal(PROJECTS.length,8);assert.equal(new Set(PROJECTS.map(p=>p.id)).size,8);assert.equal(new Set(PROJECTS.map(p=>p.signature)).size,8);
const evidence=JSON.parse(await readFile('scripts/showreel/assets/evidence.json','utf8'));
for(const [id,item]of Object.entries(evidence)){
 const body=await readFile('scripts/showreel/assets/'+item.file);assert.equal(createHash('sha256').update(body).digest('hex'),item.sha256,id+' texture integrity');
}
const report={};
for(const mode of ['master','hero']){
 const duration=mode==='master'?FILM.masterDuration:FILM.heroDuration;const layout=projectLayout(mode);const seen=new Set();let cropped=0,maxRotation=0;let previous;
 const samples=[];
 for(let frame=0;frame<=duration*30;frame++){
  const state=stateAt(mode,frame/30);const camera=new THREE.PerspectiveCamera(42,16/9,.15,250);camera.position.fromArray(state.position);camera.lookAt(...state.target);camera.updateMatrixWorld();
  assert(state.position.every(Number.isFinite));assert(state.target.every(Number.isFinite));
  if(previous)maxRotation=Math.max(maxRotation,previous.angleTo(camera.quaternion));previous=camera.quaternion.clone();
  if(state.opacity>.98){seen.add(state.project.id);for(const corner of [[-4.8,-3.15,.04],[4.8,-3.15,.04],[4.8,3.3,.04],[-4.8,3.3,.04]]){
   const v=new THREE.Vector3(...localToWorld(state.project,corner)).project(camera);if(Math.abs(v.x)>1||Math.abs(v.y)>1)cropped++;
  }}
  if(frame%30===0)samples.push({time:state.time,project:state.project.id,camera:state.position,target:state.target});
 }
 assert.equal(seen.size,layout.length,mode+' features every configured project');assert.equal(cropped,0,mode+' readable panel framing');assert(maxRotation*180/Math.PI<4,'No abrupt camera jumps');
 const positions=cameraKeys(mode).map(k=>k.position);const spans=[0,1,2].map(axis=>Math.max(...positions.map(p=>p[axis]))-Math.min(...positions.map(p=>p[axis])));assert(spans[0]>10&&spans[1]>8&&spans[2]>3,'True lateral, vertical and depth travel, not screenshot scaling');
 report[mode]={projects:[...seen],duration,wholePanelFramingViolations:cropped,maxDegreesPerFrame:maxRotation*180/Math.PI,worldAxisTravel:spans,oneSecondCameraSamples:samples};
}
const first=stateAt('hero',0),last=stateAt('hero',FILM.heroDuration);assert.deepEqual(first.position,last.position);assert.deepEqual(first.target,last.target);
console.log(JSON.stringify(report,null,2));
