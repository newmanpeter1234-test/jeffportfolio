import { chromium } from 'playwright';
import { mkdir, writeFile } from 'node:fs/promises';
import { projectLayout } from './scene/config.mjs';
const dir='.cache/showreel/inspection';await mkdir(dir,{recursive:true});
const browser=await chromium.launch({args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const logs=[];
for(const mode of ['master','hero']){
 const page=await browser.newPage({viewport:{width:1280,height:720},deviceScaleFactor:1});
 page.on('pageerror',error=>logs.push({mode,error:error.message}));
 await page.goto(`http://localhost:5050/?mode=${mode}&capture=1`);await page.waitForFunction(()=>window.__filmReady,{timeout:90000});
 const times=mode==='master'?[0,1.8,...projectLayout('master').map((p,i)=>5.15+i*4),38.5,40.9]:[0,1.65,3.3,5.25,6.8,8.85,10.766666,10.8];
 for(const time of times){
  const start=performance.now();const state=await page.evaluate(t=>window.__film.renderAt(t),time);await page.screenshot({path:`${dir}/${mode}-${time.toFixed(2)}.png`});
  const inFrame=state.featuredBounds.every(([x,y,z])=>Math.abs(x)<1&&Math.abs(y)<1&&z>0&&z<1);
  logs.push({...state,wholeMainPanelInFrame:inFrame,milliseconds:performance.now()-start});
 }
 await page.close();
}
await browser.close();await writeFile(dir+'/metrics.json',JSON.stringify(logs,null,2)+'\n');console.log(logs.map(({mode,time,project,opacity,drawCalls,triangles,wholeMainPanelInFrame,milliseconds,error})=>({mode,time,project,opacity,drawCalls,triangles,wholeMainPanelInFrame,milliseconds,error})));
