// One typography/compositing source for studio previews and deterministic exports.
export async function createHUD(width,height,source,{hideText=false}={}){
 const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;canvas.id='composite';canvas.style.zIndex='4';canvas.style.pointerEvents='none';document.body.append(canvas);
 const ctx=canvas.getContext('2d',{alpha:false});const s=width/1280;
 const logo=hideText?null:new Image();if(logo){logo.src='/favicon.svg';await logo.decode();}
 function font(size,family='FilmSans',weight=400){ctx.font=`${weight} ${size*s}px ${family}`;ctx.letterSpacing='0px';}
 function text(value,x,y,color='#c2d1c6',size=10,family='FilmSans',weight=400,align='left'){ctx.fillStyle=color;ctx.textAlign=align;font(size,family,weight);ctx.fillText(value,x*s,y*s);}
 return {canvas,draw(state){
  ctx.globalAlpha=1;ctx.drawImage(source,0,0,width,height);
  const matte=ctx.createLinearGradient(0,height*.64,0,height);matte.addColorStop(0,'#03090d00');matte.addColorStop(.42,'#03090d44');matte.addColorStop(1,'#03090df2');ctx.fillStyle=matte;ctx.fillRect(0,height*.64,width,height*.36);
  ctx.save();ctx.scale(width,height);const vignette=ctx.createRadialGradient(.5,.47,.27,.5,.5,.7);vignette.addColorStop(0,'#01040800');vignette.addColorStop(1,'#01040866');ctx.fillStyle=vignette;ctx.fillRect(0,0,1,1);ctx.restore();
  if(hideText)return;
  ctx.drawImage(logo,44*s,29*s,26*s,33*s);text('J E F R I N E   C O R R E Y A',85,42,'#c2d1c6',8,'FilmMono');text('S E C U R I T Y,  W I T H  I N T E N T.',85,58,'#819d8c',6,'FilmMono');
  text('A JOURNEY THROUGH THE WORK',1236,45,'#acc4aa',8,'FilmMono',400,'right');ctx.fillStyle='#a9c78c55';ctx.fillRect(1050*s,56*s,186*s,.7*s);
  if(state.opacity>.001){
   ctx.globalAlpha=state.opacity;const dy=(1-state.opacity)*9;const project=state.project;
   ctx.fillStyle=project.color;ctx.fillRect(44*s,(581+dy)*s,28*s,.8*s);
   text(String(state.current+1).padStart(2,'0')+' / '+(state.duration<20?'03':'08')+'  '+project.category,84,584+dy,project.color,8,'FilmMono');
   text(project.title,44,630+dy,'#edf2e9',39,'FilmDisplay',500);
   text(project.feature,44,661+dy,'#adbfba',14);
   ctx.beginPath();ctx.arc(961*s,(659+dy)*s,1.8*s,0,Math.PI*2);ctx.fillStyle=project.color;ctx.fill();
   text(project.evidence,1236,662+dy,'#afc4b5',6.7,'FilmMono',400,'right');ctx.globalAlpha=1;
  }
  if(state.outro>.001){
   ctx.globalAlpha=state.outro;text('EIGHT PROJECTS. ONE SECURITY MINDSET.',44,546,'#b5d399',8,'FilmMono');
   text('Jefrine Correya',44,615,'#edf2e9',62,'FilmDisplay',500);
   font(62,'FilmDisplay',500);const w=ctx.measureText('Jefrine Correya').width/s;text('.',44+w,615,'#c5f58a',62,'FilmDisplay',500);
   text('Beyond the noise. Security, with intent.',44,657,'#a8c0b0',15);
   text('CYBERSECURITY PORTFOLIO',1236,632,'#b7c6ba',8,'FilmMono',400,'right');text('REAL INTERFACES / PUBLISHED LAB EVIDENCE',1236,648,'#b7c6ba',8,'FilmMono',400,'right');ctx.globalAlpha=1;
  }
  text('REAL INTERFACES · LOCAL DEMOS & PUBLISHED LAB EVIDENCE · NOT LIVE TELEMETRY',44,698,'#718f81',6.5,'FilmMono');text('JEFFSEC / PROJECT FILM',1236,698,'#91ad91',6.5,'FilmMono',400,'right');
 },export(format='png'){return canvas.toDataURL(format==='jpeg'?'image/jpeg':'image/png',.97).split(',')[1];}};
}
