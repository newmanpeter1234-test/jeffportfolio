import * as THREE from 'three';
export function canvasTexture(width,height,draw){
 const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;draw(canvas.getContext('2d'),width,height);
 const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;texture.anisotropy=4;return texture;
}
export function textPlane({lines,width=8,height=2,color='#eef3e9',font='FilmDisplay',size=140,background=null,accent='#c5f58a',align='left',secondaryScale=.66}){
 const map=canvasTexture(1600,Math.round(1600*height/width),(ctx,w,h)=>{
  if(background){ctx.fillStyle=background;ctx.fillRect(0,0,w,h);ctx.strokeStyle=accent+'77';ctx.lineWidth=3;ctx.strokeRect(2,2,w-4,h-4);}
  ctx.textBaseline='middle';ctx.textAlign=align;ctx.fillStyle=color;
  const x=align==='center'?w/2:background?45:6;
  lines.forEach((line,i)=>{ctx.font=`${i===0?'600':'400'} ${i===0?size:Math.round(size*secondaryScale)}px ${i===0?font:'FilmMono'}`;ctx.fillStyle=i===0?color:accent;ctx.fillText(line,x,h*(i+.6)/(lines.length+.15),w-(background?90:12));});
 });
 const material=new THREE.MeshBasicMaterial({map,transparent:true,depthWrite:false,toneMapped:false});const mesh=new THREE.Mesh(new THREE.PlaneGeometry(width,height),material);return mesh;
}
export function sourceCard(project){
 const code=project.code;const lines=code||project.note;
 const map=canvasTexture(1350,code?360:410,(ctx,w,h)=>{
  ctx.fillStyle='#09131bec';ctx.fillRect(0,0,w,h);ctx.strokeStyle=project.color+'88';ctx.lineWidth=3;ctx.strokeRect(2,2,w-4,h-4);
  ctx.fillStyle=project.color;ctx.font='400 26px FilmMono';ctx.fillText(code?project.codeLabel:'PROJECT NOTES / SCOPE',42,53);
  lines.forEach((text,i)=>{ctx.fillStyle=i===0?'#f0f5ec':'#b6cbbf';ctx.font=`400 ${code?43:40}px ${code?'FilmMono':'FilmSans'}`;ctx.fillText(text,42,124+i*72,w-84);});
 });
 const mesh=new THREE.Mesh(new THREE.PlaneGeometry(5.6,code?1.5:1.7),new THREE.MeshBasicMaterial({map,transparent:true,toneMapped:false,depthWrite:false}));return mesh;
}
