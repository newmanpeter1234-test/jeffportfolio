import * as THREE from 'three';
import { FILM, projectLayout } from '../scene/config.mjs';
import { stateAt, smooth } from '../scene/timeline.mjs';
import { createEnvironment } from './environment.mjs';
import { createPanel } from './panel.mjs';
import { textPlane } from './typography.mjs';
import { createHUD } from './hud.mjs';
import { createCleanPanel } from '../../native-clean/panel.mjs';
const params=new URLSearchParams(location.search);const mode=params.get('mode')==='hero'?'hero':'master';
const clean=params.get('clean')==='1';
if(params.has('capture'))document.body.classList.add('capture');
document.body.style.setProperty('--scale',String(innerWidth/1280));
const width=innerWidth,height=innerHeight;
const scene=new THREE.Scene();const camera=new THREE.PerspectiveCamera(42,width/height,.15,250);
const renderer=new THREE.WebGLRenderer({canvas:document.getElementById('scene'),antialias:true,preserveDrawingBuffer:true,powerPreference:'high-performance'});
renderer.setPixelRatio(1);renderer.setSize(width,height,false);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1;
await Promise.all(['500 16px FilmDisplay','700 16px FilmDisplay','400 16px FilmMono','400 16px FilmSans','600 16px FilmSans'].map(font=>document.fonts.load(font)));
const projects=projectLayout(mode);const environment=createEnvironment(scene,projects,FILM.seed);const loader=new THREE.TextureLoader();
const panels=[];for(const project of projects){const panel=await (clean?createCleanPanel:createPanel)(project,loader,{anisotropy:Math.min(16,renderer.capabilities.getMaxAnisotropy())});panels.push(panel);scene.add(panel.group);}
const identity=clean?null:textPlane({lines:['Jefrine Correya.','SECURITY, WITH INTENT.'],width:12,height:3.5,size:174,color:'#eef3e9',accent:'#c5f58a',align:'center',secondaryScale:.25});if(identity){identity.position.set(0,.7,13);scene.add(identity);}
const hud=await createHUD(width,height,renderer.domElement,{hideText:clean});
document.getElementById('film').style.display='none';
const elements={timeline:document.getElementById('timeline'),'time-label':document.getElementById('time-label')};
function renderAt(time){
 const state=stateAt(mode,time);camera.position.fromArray(state.position);camera.lookAt(...state.target);camera.updateMatrixWorld();
 environment.animate(state.time,state.duration);panels.forEach(panel=>panel.animate(state));
 if(identity){identity.visible=state.intro>.001;identity.material.opacity=state.intro;identity.rotation.y=Math.sin(state.time*.3)*.035;}
 elements.timeline.max=state.duration;elements.timeline.value=state.time;elements['time-label'].textContent=state.time.toFixed(2)+' s';
 renderer.render(scene,camera);hud.draw(state);
 const active=panels.find(p=>p.project.id===state.project.id);const bounds=active.bounds().map(point=>point.project(camera).toArray());
 return {time:state.time,mode,clean,nativeWidth:width,nativeHeight:height,editorialCards:clean?0:undefined,project:state.project.id,projectTitle:state.project.title,opacity:state.opacity,intro:state.intro,outro:state.outro,cameraPosition:camera.position.toArray(),cameraTarget:state.target,cameraQuaternion:camera.quaternion.toArray(),cameraMatrix:camera.matrixWorld.toArray(),featuredBounds:bounds,drawCalls:renderer.info.render.calls,triangles:renderer.info.render.triangles,textures:renderer.info.memory.textures,geometries:renderer.info.memory.geometries};
}
window.__film={mode,duration:mode==='hero'?FILM.heroDuration:FILM.masterDuration,projects:projects.map(p=>p.id),clean,audit:clean?panels.map(p=>({id:p.project.id,...p.audit})):null,renderAt,exportFrame:format=>hud.export(format),dispose(){renderer.dispose();environment.dispose();},renderer:'Three.js PerspectiveCamera / explicit deterministic world-space poses'};
renderAt(mode==='hero'?1.65:0);window.__filmReady=true;
let running=false,origin=0,current=0;
document.getElementById('toggle').onclick=()=>{running=!running;origin=performance.now()-current*1000;document.getElementById('toggle').textContent=running?'Pause':'Play';};
elements.timeline.addEventListener('input',()=>{current=Number(elements.timeline.value);origin=performance.now()-current*1000;renderAt(current);});
function animate(now){if(running){current=((now-origin)/1000)%window.__film.duration;renderAt(current);}requestAnimationFrame(animate);}
if(!params.has('capture'))requestAnimationFrame(animate);
