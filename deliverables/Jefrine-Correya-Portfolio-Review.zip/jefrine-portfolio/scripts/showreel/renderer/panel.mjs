import * as THREE from 'three';
import { smooth } from '../scene/timeline.mjs';
import { canvasTexture, textPlane, sourceCard } from './typography.mjs';
function roundedRect(width,height,radius){
 const x=-width/2,y=-height/2,s=new THREE.Shape();s.moveTo(x+radius,y);s.lineTo(x+width-radius,y);s.quadraticCurveTo(x+width,y,x+width,y+radius);s.lineTo(x+width,y+height-radius);s.quadraticCurveTo(x+width,y+height,x+width-radius,y+height);s.lineTo(x+radius,y+height);s.quadraticCurveTo(x,y+height,x,y+height-radius);s.lineTo(x,y+radius);s.quadraticCurveTo(x,y,x+radius,y);return s;
}
function imageFace(texture,width,maxHeight){
 const ratio=texture.image.width/texture.image.height;let h=width/ratio,w=width;if(h>maxHeight){h=maxHeight;w=h*ratio;}
 return new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshBasicMaterial({map:texture,transparent:true,toneMapped:false}));
}
export async function createPanel(project,loader){
 const group=new THREE.Group();group.position.fromArray(project.position);group.rotation.y=project.yaw;
 const baseAlpha=new Map();
 const frameMaterial=new THREE.MeshStandardMaterial({color:0x15232a,metalness:.72,roughness:.3,transparent:true});
 const frame=new THREE.Mesh(new THREE.ExtrudeGeometry(roundedRect(9.96,6.65,.15),{depth:.18,bevelEnabled:true,bevelThickness:.05,bevelSize:.05,bevelSegments:2,curveSegments:5,steps:1}),frameMaterial);frame.position.z=-.22;group.add(frame);
 const glass=new THREE.Mesh(new THREE.PlaneGeometry(9.65,6.03),new THREE.MeshBasicMaterial({color:0x070e13,transparent:true}));glass.position.set(0,-.14,.02);group.add(glass);
 const texture=await loader.loadAsync('/evidence/'+project.id+'.webp');texture.colorSpace=THREE.SRGBColorSpace;texture.anisotropy=4;
 const screen=imageFace(texture,9.6,6);screen.position.set(0,-.14,.035);group.add(screen);
 const chrome=canvasTexture(1600,70,(ctx,w,h)=>{
  ctx.fillStyle='#152127';ctx.fillRect(0,0,w,h);ctx.fillStyle='#b1c3b0';
  for(let i=0;i<3;i++){ctx.beginPath();ctx.arc(31+i*19,35,5,0,Math.PI*2);ctx.fill();}
  ctx.fillStyle='#bbcabb';ctx.font='400 18px FilmMono';ctx.fillText(project.repo+' / source capture',112,42);
  ctx.fillStyle=project.color;ctx.fillRect(w-155,32,95,2);
 });
 const chromeMesh=new THREE.Mesh(new THREE.PlaneGeometry(9.6,.42),new THREE.MeshBasicMaterial({map:chrome,transparent:true,toneMapped:false}));chromeMesh.position.set(0,3.08,.05);group.add(chromeMesh);
 const edge=new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(9.97,6.66,.21)),new THREE.LineBasicMaterial({color:project.color,transparent:true,opacity:.4}));edge.position.z=-.10;group.add(edge);
 const rule=new THREE.Mesh(new THREE.PlaneGeometry(2.2,.018),new THREE.MeshBasicMaterial({color:project.color,transparent:true}));rule.position.set(-3.6,-3.54,0);group.add(rule);
 const label=textPlane({lines:[project.title],width:9.8,height:.55,size:59,color:'#c5d4c8',font:'FilmDisplay'});label.position.set(-.05,-4.0,-.4);group.add(label);
 const number=textPlane({lines:[String(project.index+1).padStart(2,'0')],width:4.8,height:4.6,size:750,color:'#385147'});number.position.set(-5.8,2.0,-3.5);group.add(number);
 let floating;
 if(project.detail){
  const detailTexture=await loader.loadAsync('/evidence/'+project.detail+'.webp');detailTexture.colorSpace=THREE.SRGBColorSpace;detailTexture.anisotropy=4;
  floating=imageFace(detailTexture,project.id==='astra'?6.1:5.5,4.5);
  floating.position.set(project.id==='astra'?.35:-1.7,project.id==='astra'?-.15:-1.7,1.15);
 }else{floating=sourceCard(project);floating.position.set(1.6,-1.75,.85);}
 group.add(floating);
 group.traverse(object=>{if(object.material){const materials=Array.isArray(object.material)?object.material:[object.material];materials.forEach(material=>{baseAlpha.set(material,material.opacity);material.transparent=true;});}});
 return {project,group,screen,frame,floating,animate(state){
  const active=state.project.id===project.id&&state.opacity>0;
  const brightness=state.intro>.05 ? .08 : state.outro>.1 ? .78 : .16+.84*(state.project.id===project.id?state.opacity:0);
  baseAlpha.forEach((alpha,material)=>{material.opacity=alpha*brightness;});
  const entrance=smooth((state.local-.6)/.55);const exit=1-smooth((state.local-(state.duration<20?2.75:3.15))/.45);const amount=active?entrance*exit:0;
  label.material.opacity=brightness*(state.project.id===project.id?1-state.opacity:1);
  floating.visible=amount>.005;floating.material.opacity=amount;
  floating.position.z=(project.id==='astra'?1.15:.85)+.35*amount;
  floating.rotation.y=(1-amount)*-.10;
 },bounds(){return [[-4.8,-3.15,.04],[4.8,-3.15,.04],[4.8,3.3,.04],[-4.8,3.3,.04]].map(v=>group.localToWorld(new THREE.Vector3(...v)));}};
}
