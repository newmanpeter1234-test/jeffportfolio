// Deterministic sequential renderer. One browser, one frame in flight, no frame directory.
import { chromium } from 'playwright';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { mkdir, writeFile, stat, rename } from 'node:fs/promises';
import { build } from 'esbuild';
import path from 'node:path';
import { FILM } from './scene/config.mjs';
const flags=Object.fromEntries(process.argv.slice(2).map(argument=>{const[k,v]=argument.replace(/^--/,'').split('=');return[k,v??true];}));
const mode=flags.mode==='hero'?'hero':'master';const width=Number(flags.width||1280),height=Number(flags.height||720),fps=Number(flags.fps||30),crf=Number(flags.crf||23);
if(width%2||height%2||Math.abs(width/height-16/9)>.001||!Number.isFinite(fps)||fps<1||fps>60)throw new Error('Use even 16:9 dimensions and 1–60 fps.');
const duration=mode==='hero'?FILM.heroDuration:FILM.masterDuration;const frames=Math.round(duration*fps);
const output=path.resolve(flags.output||`public/media/cybersecurity-${mode==='hero'?'hero-loop':'showreel'}.mp4`);await mkdir(path.dirname(output),{recursive:true});await mkdir('.cache/showreel/exports',{recursive:true});
await build({entryPoints:['scripts/showreel/renderer/main.mjs'],bundle:true,format:'esm',target:'es2022',outfile:'.cache/showreel/studio/studio.js'});
const temporary=path.resolve(`.cache/showreel/exports/${mode}.rendering.mp4`);
const args=['--no-sandbox'];if(flags.software===true||flags.software==='1'||process.env.SHOWREEL_SOFTWARE_GL==='1')args.push('--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader');
const browser=await chromium.launch({args});const page=await browser.newPage({viewport:{width,height},deviceScaleFactor:1});const errors=[];page.on('pageerror',error=>errors.push(error.message));
let ffmpeg;
try{
 await page.goto(`http://localhost:${process.env.SHOWREEL_PORT||5050}/?mode=${mode}&capture=1`);await page.waitForFunction(()=>window.__filmReady,undefined,{timeout:90000});
 ffmpeg=spawn('ffmpeg',['-y','-f','image2pipe','-vcodec','mjpeg','-framerate',String(fps),'-i','pipe:0','-an','-c:v','libx264','-preset','slow','-crf',String(crf),'-profile:v','main','-pix_fmt','yuv420p','-vf','scale=out_color_matrix=bt709:out_range=tv,format=yuv420p','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-movflags','+faststart','-threads','2',temporary],{stdio:['pipe','ignore','pipe']});
 let encoderLog='';ffmpeg.stderr.on('data',data=>{encoderLog=(encoderLog+data.toString()).slice(-12000);});ffmpeg.stdin.on('error',()=>{});
 const started=Date.now();const telemetry=[];
 for(let frame=0;frame<frames;frame++){
  const result=await page.evaluate(time=>{const state=window.__film.renderAt(time);return {state,jpeg:window.__film.exportFrame('jpeg')};},frame/fps);
  const bytes=Buffer.from(result.jpeg,'base64');if(!ffmpeg.stdin.write(bytes))await once(ffmpeg.stdin,'drain');
  telemetry.push({frame,...result.state});
  if(frame%Math.max(1,Math.round(fps*2))===0)console.log(JSON.stringify({mode,frame,frames,time:Number((frame/fps).toFixed(2)),project:result.state.project,elapsedSeconds:Number(((Date.now()-started)/1000).toFixed(1))}));
  if(errors.length)throw new Error(errors.join('; '));
 }
 ffmpeg.stdin.end();const[code]=await once(ffmpeg,'close');if(code!==0)throw new Error(encoderLog);
 await rename(temporary,output);
 await writeFile(`.cache/showreel/exports/${mode}-telemetry.json`,JSON.stringify(telemetry));
 const summary={mode,duration,frames,fps,width,height,crf,output,bytes:(await stat(output)).size,elapsedSeconds:(Date.now()-started)/1000,errors,renderer:'Three.js actual PerspectiveCamera and world-space panels',drawCallsMax:Math.max(...telemetry.map(t=>t.drawCalls)),trianglesMax:Math.max(...telemetry.map(t=>t.triangles)),texturesMax:Math.max(...telemetry.map(t=>t.textures)),encoder:'H.264 Main / yuv420p / faststart / no audio',framePipeline:'Sequential Canvas composite JPEG97 -> FFmpeg pipe, bounded backpressure, two encoder threads'};
 await writeFile(`.cache/showreel/exports/${mode}-summary.json`,JSON.stringify(summary,null,2)+'\n');console.log('RENDER_COMPLETE',JSON.stringify(summary));
}finally{if(ffmpeg&&!ffmpeg.stdin.destroyed)ffmpeg.stdin.end();await browser.close();}
