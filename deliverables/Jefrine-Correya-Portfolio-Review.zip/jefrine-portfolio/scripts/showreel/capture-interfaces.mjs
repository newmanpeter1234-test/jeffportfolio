// Original project UIs only. No API/scan submission and no real passwords.
import { chromium } from 'playwright';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
const root=path.resolve('.cache/showreel/raw-captures'); await mkdir(root,{recursive:true});
const browser=await chromium.launch({args:['--no-sandbox']});
const results=[];
for(const [id,url] of [['url','http://localhost:5052/url'],['scanner','http://localhost:5052/scanner'],['passchecker','http://localhost:5052/passchecker'],['soc','http://localhost:5053']]){
 const page=await browser.newPage({viewport:{width:1280,height:800},deviceScaleFactor:1,reducedMotion:'reduce'});
 const errors=[],submissions=[],external=[];
 page.on('pageerror',e=>errors.push(e.message));
 await page.route('**/*',route=>{
  const request=route.request();const u=new URL(request.url());
  if(!['localhost','127.0.0.1'].includes(u.hostname)&&/^https?:/.test(u.protocol)){external.push(u.hostname);return route.abort();}
  if(request.method()!=='GET'&&!request.url().includes('_stcore')){submissions.push(request.url());return route.abort();}
  return route.continue();
 });
 await page.goto(url,{waitUntil:'networkidle'});
 if(id==='soc'){
  await page.getByRole('heading',{name:'SOC Threat Detection Agent',exact:true}).waitFor();
  await page.addStyleTag({content:'.tip-card,[data-testid="stHeader"],[data-testid="stToolbar"]{display:none!important}[data-testid="stMainBlockContainer"]{padding-top:3rem!important}'});
 }
 await page.addStyleTag({content:'*,*::before,*::after{animation:none!important;transition:none!important;caret-color:transparent!important}html{scroll-behavior:auto!important}'});
 if(id==='scanner')await page.locator('#scan').scrollIntoViewIfNeeded();
 if(id==='passchecker'){
  await page.locator('#passwordInput').fill('Showcase-Example-2026!');
  await page.waitForTimeout(150);
  console.log('Local heuristic feedback:',await page.locator('#feedback').innerText());
 }
 await page.evaluate(()=>document.fonts.ready);
 await page.screenshot({path:path.join(root,id+'.png')});
 if(id==='scanner')await page.locator('#scan').screenshot({path:path.join(root,'scanner-panel.png')});
 if(id==='url')await page.locator('.bg-blur').screenshot({path:path.join(root,'url-panel.png')});

 results.push({id,errors,submissions,externalRequestsBlocked:[...new Set(external)],url});
 await page.close();
}
await browser.close();await writeFile(path.join(root,'capture-results.json'),JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify(results,null,2));
