"""Turn genuine captures/report images into bounded, traceable render textures."""
from pathlib import Path
from PIL import Image, ImageDraw
import pymupdf as fitz
import hashlib, json, subprocess
ROOT=Path(__file__).resolve().parents[2]
CACHE=ROOT/'.cache/showreel';SOURCE=CACHE/'sources';RAW=CACHE/'raw-captures';OUT=ROOT/'scripts/showreel/assets'
OUT.mkdir(parents=True,exist_ok=True);RAW.mkdir(parents=True,exist_ok=True)
manifest={}
def image_asset(name,source,origin,crop=None,redactions=None,note=''):
    im=source.copy().convert('RGB') if isinstance(source,Image.Image) else Image.open(source).convert('RGB')
    if crop:im=im.crop(crop)
    if redactions:
        draw=ImageDraw.Draw(im)
        for rectangle in redactions:draw.rectangle(rectangle,fill='#172023')
    if im.width>1440:im.thumbnail((1440,1000))
    path=OUT/(name+'.webp');im.save(path,quality=91,method=6)
    manifest[name]={'file':path.name,'width':im.width,'height':im.height,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'source':origin,'crop':crop,'redactions':redactions,'note':note}
def pdf_image(file,page,index):
    import io
    doc=fitz.open(file);item=doc[page-1].get_images(full=True)[index];data=doc.extract_image(item[0]);return Image.open(io.BytesIO(data['image']))
subprocess.run(['ffmpeg','-y','-ss','0.9','-i',str(ROOT/'public/media/astra-hero.mp4'),'-frames:v','1',str(RAW/'astra-table.png'),'-loglevel','error'],check=True)
image_asset('astra',RAW/'astra-table.png','public/media/astra-hero.mp4 @ 0.9s',note='Existing verified source capture. Original sample fixtures, no new telemetry.')
image_asset('astra-detail',ROOT/'public/images/astra-hero-poster.webp','public/images/astra-hero-poster.webp',crop=(216,106,936,614),note='Actual implemented modal, cropped from verified original capture. Reconstructed as a depth-separated interface layer.')
image_asset('splunk',pdf_image(SOURCE/'splunk-soc-lab/reports/Jefrin_Final_SOC_Report.pdf',11,0),'splunk-soc-lab/reports/Jefrin_Final_SOC_Report.pdf, page 11, embedded image',crop=(114,180,1080,606),note='Actual published Splunk alert-list screen, not a dashboard mockup. Browser address and OS taskbar omitted.')
image_asset('wazuh',pdf_image(SOURCE/'wazuh-siem-lab/report/PROJECT_ON_WAZUH.pdf',19,0),'wazuh-siem-lab/report/PROJECT_ON_WAZUH.pdf, page 19, first embedded image',note='Actual published threat-hunting interface, historical lab evidence.')
image_asset('wazuh-detail',pdf_image(SOURCE/'wazuh-siem-lab/report/PROJECT_ON_WAZUH.pdf',19,1),'wazuh-siem-lab/report/PROJECT_ON_WAZUH.pdf, page 19, second embedded image',note='Actual published event-table detail. Not live monitoring.')
packet_image=Image.open(SOURCE/'wireshark-network-traffic-analysis/images/PHOTO-2025-10-27-21-11-29.jpg').convert('RGB').resize((1568,983),Image.Resampling.LANCZOS)
image_asset('wireshark',packet_image,'wireshark-network-traffic-analysis/images/PHOTO-2025-10-27-21-11-29.jpg',crop=(0,0,1568,716),redactions=[(136,47,414,716),(550,333,1568,353),(550,674,1568,697)],note='3836×2404 source normalized to 1568×983 before coordinates are applied. Published packet list: both address columns and SNI rows redacted; payload/MAC/SSID/filename panes omitted. No fresh packet capture.')
for name,origin,filename,note in [
 ('soc','-soc-agent-streamlit/soc-agent-streamlit/app.py','soc.png','Original Streamlit UI. Dotenv, credentials and external API calls disabled in the capture environment. Unverified tip omitted. No analysis submitted.'),
 ('url','URL-Phishing-Detector2/templates/index.html','url-panel.png','Original form with original background loaded, cropped to the real form to exclude decorative background art. No URL submitted.'),
 ('scanner','web-vuln-scanner/templates/index.html','scanner-panel.png','Original configuration section. No scan initiated; marketing/demo placeholders excluded.'),
 ('passchecker','password_strength_checker/index.html','passchecker.png','Original client-side feedback on synthetic Showcase-Example-2026!; input remains masked. Heuristic, not a security guarantee.'),
]:image_asset(name,RAW/filename,origin,note=note)
(OUT/'evidence.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Prepared '+str(len(manifest))+' genuine bounded textures; source pins and redactions documented.')
