"""Track existing video planes. No scene models, camera rigs or original textures are used."""
from pathlib import Path
import cv2, numpy as np, json, hashlib
ROOT=Path(__file__).resolve().parents[2]
CFG=json.loads((Path(__file__).with_name('edit.json')).read_text())
CACHE=ROOT/'.cache/glass-footage';CACHE.mkdir(parents=True,exist_ok=True)
SOURCE=ROOT/CFG['source']
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==CFG['sourceSha256']
cv2.setNumThreads(2)
cap=cv2.VideoCapture(str(SOURCE));fps=cap.get(cv2.CAP_PROP_FPS);total=int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
frames=[]
while True:
 ok,frame=cap.read()
 if not ok:break
 frames.append(cv2.cvtColor(cv2.resize(frame,(640,360)),cv2.COLOR_BGR2GRAY))
cap.release()
UV=np.float32([[0,0],[1,0],[1,1],[0,1]])
def mask_for(quad):
 mask=np.zeros((360,640),np.uint8);cv2.fillConvexPoly(mask,np.int32(quad),255)
 H=cv2.getPerspectiveTransform(UV,np.float32(quad));inner=cv2.perspectiveTransform(np.float32([[[.08,.35],[.92,.35],[.92,.93],[.08,.93]]]),H)[0]
 cv2.fillConvexPoly(mask,np.int32(inner),0)
 return mask
def seed(gray,q):
 return cv2.goodFeaturesToTrack(gray,250,.002,4,mask=mask_for(q),blockSize=5)
def valid(q,old):
 a=abs(cv2.contourArea(np.float32(q)));b=abs(cv2.contourArea(np.float32(old)))
 return np.isfinite(q).all() and a>150 and a<1800000 and .30<a/max(b,1)<3 and cv2.isContourConvex(np.int32(q))
tracks={};diagnostics={}
for anchor in CFG['anchors']:
 idx=round(anchor['time']*fps);quad=np.float32(anchor['quad'])*.5
 values={idx:{'quad':(quad*2).round(3).tolist(),'confidence':1}}
 for direction in [-1,1]:
  prev=frames[idx];q=quad.copy();pts=seed(prev,q);last_velocity=np.zeros_like(q);fails=0
  begin=idx+direction;end=round(anchor['range'][0 if direction<0 else 1]*fps)
  for n in range(begin,end+direction,direction):
   if n<0 or n>=total:break
   nxt=frames[n];quality=0;newq=None
   if pts is not None and len(pts)>=6:
    p2,status,_=cv2.calcOpticalFlowPyrLK(prev,nxt,pts,None,winSize=(27,27),maxLevel=4,criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,28,.01))
    if p2 is not None:
     back,bs,_=cv2.calcOpticalFlowPyrLK(nxt,prev,p2,None,winSize=(27,27),maxLevel=4)
     ok=(status.ravel()==1)&(bs.ravel()==1)&(np.linalg.norm(back-pts,axis=2).ravel()<1.3)
     a=pts[ok].reshape(-1,2);b=p2[ok].reshape(-1,2)
     if len(a)>=6:
      H,inliers=cv2.findHomography(a,b,cv2.RANSAC,1.15)
      if H is not None:
       candidate=cv2.perspectiveTransform(q[None],H)[0]
       if valid(candidate,q) and inliers.sum()>=6:
        newq=candidate;quality=float(inliers.mean());pts=b[inliers.ravel()==1].reshape(-1,1,2)
   if newq is None:
    fails+=1
    if fails>3:break
    newq=q+last_velocity;quality=.1
   else:fails=0
   last_velocity=(newq-q)*.65+last_velocity*.35;q=newq
   values[n]={'quad':(q*2).round(3).tolist(),'confidence':round(quality,3)}
   prev=nxt
   if quality<.45 or n%8==0 or pts is None or len(pts)<45:pts=seed(prev,q)
  print(anchor['id'],'direction',direction,'through',n,'frames',len(values),flush=True)
 tracks[anchor['id']]=values;diagnostics[anchor['id']]={'anchorFrame':idx,'coveredFrames':len(values),'frameRange':[min(values),max(values)]}
(CACHE/'tracks.json').write_text(json.dumps({'fps':fps,'sourceFrames':total,'sourceSha256':CFG['sourceSha256'],'tracks':tracks,'diagnostics':diagnostics},separators=(',',':')))
print(json.dumps(diagnostics,indent=2))
