"""Remove residual low-opacity chapter halos using only the original footage's numeral masks."""
from pathlib import Path
from collections import OrderedDict
import cv2,numpy as np,json,subprocess,time,hashlib
from composite import ROOT,CONFIG,TRACKS,poly_mask
CACHE=ROOT/'.cache/glass-footage';DEST=ROOT/'public/media/cybersecurity-liquid-glass-loop.mp4';INPUT=CACHE/'before-numeral-polish.mp4'
if not INPUT.exists():DEST.rename(INPUT)
recipe=json.loads((CACHE/'export-report.json').read_text());xs=np.array(recipe['sourceToBaseTimeMap']['sourceSeconds']);ys=np.array(recipe['sourceToBaseTimeMap']['targetSeconds']);S=CONFIG['sourceRange'][0]
source=cv2.VideoCapture(str(ROOT/CONFIG['source']));cached=OrderedDict();last=-2
cv2.setNumThreads(2)
def original(n):
 global last
 if n not in cached:
  if n!=last+1:source.set(cv2.CAP_PROP_POS_FRAMES,n)
  ok,a=source.read();last=n
  if not ok:raise RuntimeError(n)
  cached[n]=a
  if len(cached)>48:cached.popitem(last=False)
 return cached[n]
def source_n(base_t):return round((S+float(np.interp(base_t,ys,xs)))*30)
def rectangles(n):
 im=original(n);f=im.astype(float);gray=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY).astype(float);protect=np.zeros((720,1280),np.uint8)
 for p in CONFIG['anchors'][:8]:
  a=TRACKS[p['id']].get(str(n))
  if a:protect|=poly_mask(np.float32(a['quad']))
 ratio=f[:,:,2]/np.maximum(np.maximum(f[:,:,0],f[:,:,1]),1)
 signal=((ratio>.48)&(ratio<.80)&(f[:,:,1]>f[:,:,2]+1)&(f[:,:,0]>f[:,:,2]+.5)&(gray>10)&(gray-cv2.GaussianBlur(gray,(0,0),12)>1)&(protect==0)).astype(np.uint8)*255
 signal=cv2.morphologyEx(signal,cv2.MORPH_CLOSE,np.ones((11,11),np.uint8));contours,_=cv2.findContours(signal,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE);out=[]
 for c in contours:
  x,y,w,h=cv2.boundingRect(c)
  if 28<h<240 and 5<w<230 and cv2.contourArea(c)>40:
   out.append((max(0,x-17),max(0,y-17),min(1280,x+w+17),min(720,y+h+17)))
 return out,protect
cap=cv2.VideoCapture(str(INPUT));enc=subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','bgr24','-s','1280x720','-r','60','-i','pipe:0','-an','-vf','scale=1920:1080:flags=lanczos:out_color_matrix=bt709:out_range=tv,format=yuv420p','-c:v','libx264','-preset','slow','-crf','18','-profile:v','high','-level:v','4.2','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-movflags','+faststart','-threads','2',str(DEST)],stdin=subprocess.PIPE)
start=time.time();regions=0
for i in range(1080):
 ok,raw=cap.read()
 if not ok:raise RuntimeError(i)
 im=cv2.resize(raw,(1280,720),interpolation=cv2.INTER_AREA);t=i/60;ns=[source_n(t+.6)]
 if t>=17.4:ns.append(source_n(t-17.4))
 for n in ns:
  rects,protect=rectangles(n);orig=original(n);gray=cv2.cvtColor(orig,cv2.COLOR_BGR2GRAY)
  for x0,y0,x1,y1 in rects:
   ex0=max(0,x0-30);ex1=min(1280,x1+30);ey0=max(0,y0-30);ey1=min(720,y1+30)
   use=np.ones((ey1-ey0,ex1-ex0),bool);use[y0-ey0:y1-ey0,x0-ex0:x1-ex0]=False
   use&=(protect[ey0:ey1,ex0:ex1]==0)&(gray[ey0:ey1,ex0:ex1]<31)
   ry,rx=np.where(use)
   if len(rx)<30:continue
   select=np.linspace(0,len(rx)-1,min(len(rx),1400),dtype=int);ry=ry[select];rx=rx[select]
   A=np.c_[np.ones(len(rx)),rx/max(ex1-ex0,1),ry/max(ey1-ey0,1)];cols=orig[ey0:ey1,ex0:ex1][ry,rx].astype(float);fit=np.linalg.lstsq(A,cols,rcond=None)[0]
   residual=np.max(np.abs(A@fit-cols),axis=1);keep=residual<max(3,np.percentile(residual,65))
   if keep.sum()>25:fit=np.linalg.lstsq(A[keep],cols[keep],rcond=None)[0]
   yy,xx=np.mgrid[y0-ey0:y1-ey0,x0-ex0:x1-ex0];plate=np.clip(fit[0]+xx[:,:,None]/max(ex1-ex0,1)*fit[1]+yy[:,:,None]/max(ey1-ey0,1)*fit[2],0,33)
   m=np.ones((y1-y0,x1-x0),np.uint8);m[protect[y0:y1,x0:x1]>0]=0;m[[0,-1],:]=0;m[:,[0,-1]]=0
   a=np.clip(cv2.distanceTransform(m,cv2.DIST_L2,3)/7,0,1)[:,:,None]
   im[y0:y1,x0:x1]=np.uint8(im[y0:y1,x0:x1]*(1-a)+plate*a);regions+=1
 enc.stdin.write(im.tobytes())
 if i%180==0:print(json.dumps({'stage':'numeral-polish','frame':i,'elapsed':round(time.time()-start,1)}),flush=True)
enc.stdin.close();assert enc.wait()==0;cap.release();source.release();report={'frames':1080,'regions':regions,'bytes':DEST.stat().st_size,'sha256':hashlib.sha256(DEST.read_bytes()).hexdigest(),'seconds':round(time.time()-start,2),'scope':'Only source-derived chapter numeral/halo regions; local original-footage background fit. No new camera or environment.'};(CACHE/'polish-report.json').write_text(json.dumps(report,indent=2)+'\n');print('POLISH_COMPLETE',json.dumps(report),flush=True)
