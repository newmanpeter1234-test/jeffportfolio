"""Footage-only cleanup and tracked glass compositing. Never renders a replacement scene."""
from pathlib import Path
import cv2, numpy as np, json
ROOT=Path(__file__).resolve().parents[2]
CONFIG=json.loads(Path(__file__).with_name('edit.json').read_text())
DATA=json.loads((ROOT/'.cache/glass-footage/tracks.json').read_text())
TRACKS=DATA['tracks'];W,H=1280,720
UV=np.float32([[0,0],[1,0],[1,1],[0,1]])
YY,XX=np.mgrid[0:H,0:W].astype(np.float32)
cv2.setNumThreads(2)

def poly_mask(q):
 m=np.zeros((H,W),np.uint8);cv2.fillConvexPoly(m,np.int32(q),255);return m

def region(q,box):
 M=cv2.getPerspectiveTransform(UV,np.float32(q));a,b,c,d=box
 corners=cv2.perspectiveTransform(np.float32([[[a,b],[c,b],[c,d],[a,d]]]),M)[0]
 return poly_mask(corners)

def active_tracks(index):
 out=[]
 for a in CONFIG['anchors']:
  item=TRACKS[a['id']].get(str(index))
  if item and item['confidence']>=.25:
   q=np.float32(item['quad']);area=abs(cv2.contourArea(q))
   if 600<area<670000:out.append((a,q,item['confidence']))
 return out

def glyph_components(candidate,small=False):
 # Keep thin environmental connections and soft round particles. Fill letter shapes, including counters.
 n,labels,stats,_=cv2.connectedComponentsWithStats(candidate,8)
 result=np.zeros_like(candidate)
 for i in range(1,n):
  x,y,w,h,area=stats[i];density=area/max(w*h,1)
  if area<(3 if small else 12) or area>35000 or h>245 or w>600:continue
  if not small and (h<7 or (w>55 and h<5)):continue
  if w>100 and density<.10:continue
  if density<.07:continue
  if not small and max(w,h)<10:continue
  if not small and .75<w/max(h,1)<1.3 and density>.72 and max(w,h)<22:continue
  component=(labels[y:y+h,x:x+w]==i).astype(np.uint8)*255
  contours,_=cv2.findContours(component,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
  cv2.rectangle(result,(max(0,x-14),max(0,y-14)),(min(W-1,x+w+14),min(H-1,y+h+14)),255,-1)
 return result

def cleanup(frame,items):
 source=frame.copy();f=source.astype(np.float32);gray=cv2.cvtColor(source,cv2.COLOR_BGR2GRAY).astype(np.float32)
 protected=np.zeros((H,W),np.uint8)
 for a,q,_ in items:
  if a['role']=='panel':protected=cv2.bitwise_or(protected,poly_mask(q))
 protected=cv2.dilate(protected,np.ones((7,7),np.uint8))
 # Protect dim, unfeatured white interfaces as well: their native content must not become a text repair.
 light=((gray>23)&((f.max(axis=2)-f.min(axis=2))<19)).astype(np.uint8)*255
 light[protected>0]=0
 light=cv2.morphologyEx(light,cv2.MORPH_CLOSE,np.ones((3,3),np.uint8))
 contours,_=cv2.findContours(light,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
 for contour in contours:
  x,y,w,h=cv2.boundingRect(contour);area=cv2.contourArea(contour)
  if 50<w<700 and 40<h<500 and 1400<area<150000 and .5<w/h<3.8 and cv2.countNonZero(light[y:y+h,x:x+w])/(w*h)>.64:
   cv2.drawContours(protected,[contour],-1,255,-1)
 protected=cv2.dilate(protected,np.ones((5,5),np.uint8))
 residual=gray-cv2.GaussianBlur(gray,(0,0),9)
 # Original extrinsic typography is pale green; native UI is protected, not generically erased.
 green=(f[:,:,1]-f[:,:,2]>.8)&(f[:,:,0]-f[:,:,2]>.5)&(np.abs(f[:,:,1]-f[:,:,0])<24)&(f[:,:,2]>.48*np.maximum(f[:,:,0],f[:,:,1]))
 candidate=((green)&(residual>1.3)&(gray>9)&(protected==0)).astype(np.uint8)*255
 mask=glyph_components(candidate)
 repairs=[]
 # Fixed film HUD: remove logo/name, upper-right line, lower-left chapter/title and footer labels only.
 hud=np.zeros_like(mask)
 for x1,y1,x2,y2 in [(41,27,245,65),(1047,29,1241,62),(37,568,940,675),(944,645,1242,670),(38,688,1244,707)]:hud[y1:y2,x1:x2]=255
 hud_signal=((gray-cv2.GaussianBlur(gray,(0,0),4)>2)&(gray>12)&(hud>0)).astype(np.uint8)*255
 # Restrict bottom captions to their green/white glyphs, not a solid delogo rectangle.
 hud_signal=cv2.bitwise_and(hud_signal,((green)|(gray>90)).astype(np.uint8)*255)
 mask=cv2.bitwise_or(mask,hud)
 # HUD is intentionally repaired as bounded background regions; protect actual interface content.
 native=np.zeros_like(mask)
 for a,q,_ in items:
  if a['role']=='panel':native=cv2.bitwise_or(native,poly_mask(q))
 native=cv2.dilate(native,np.ones((13,13),np.uint8));mask[native>0]=0
 mask[27:65,41:245]=255
 mask[573:590,37:610]=255
 # Chrome/source-capture labels and non-UI note-card text are tracked in the video itself.
 for a,q,_ in items:
  roi=None
  if a['role']=='panel':
   roi=region(q,(.073,.020,.86,.060))
   if a['id']=='astra':roi=cv2.bitwise_or(roi,region(q,(.025,.915,.30,.982)))
  elif a['detail']=='notes':roi=region(q,(.025,.025,.97,.86))
  elif a['detail']=='code':roi=region(q,(.025,.025,.97,.24))
  if roi is not None:
   repairs.append((roi,q,a))
 mask=cv2.dilate(mask,np.ones((3,3),np.uint8))
 if np.any(mask):
  source=cv2.inpaint(source,mask,5,cv2.INPAINT_TELEA)
  # Large numbers/caption regions receive a local footage-derived smooth clean plate, not Telea's radial trails.
  nn,ll,stats,_=cv2.connectedComponentsWithStats(mask,8)
  for k in range(1,nn):
   x,y,w,h,area=stats[k]
   if area<350:continue
   x0=max(0,x-22);x1=min(W,x+w+22);y0=max(0,y-22);y1=min(H,y+h+22)
   roi=frame[y0:y1,x0:x1];localmask=mask[y0:y1,x0:x1];gg=gray[y0:y1,x0:x1]
   pp=protected[y0:y1,x0:x1]
   use=(localmask==0)&(pp==0)&(gg<65)
   ry,rx=np.where(use)
   if len(rx)<35:continue
   if len(rx)>2500:
    sel=np.linspace(0,len(rx)-1,2500,dtype=int);rx=rx[sel];ry=ry[sel]
   A=np.column_stack([np.ones(len(rx)),rx/max(w,1),ry/max(h,1)]);colors=roi[ry,rx].astype(float)
   fit=np.linalg.lstsq(A,colors,rcond=None)[0]
   residual=np.max(np.abs(A@fit-colors),axis=1);keep=residual<max(4,np.percentile(residual,75))
   if keep.sum()>30:fit=np.linalg.lstsq(A[keep],colors[keep],rcond=None)[0]
   yy,xx=np.mgrid[0:y1-y0,0:x1-x0];pred=(fit[0]+xx[:,:,None]/max(w,1)*fit[1]+yy[:,:,None]/max(h,1)*fit[2]);pred=np.clip(pred,0,65).astype(np.uint8)
   own=(ll[y0:y1,x0:x1]==k)
   feather=cv2.distanceTransform(own.astype(np.uint8),cv2.DIST_L2,3)
   alpha=np.clip(feather/7,0,1)[:,:,None]
   dst=source[y0:y1,x0:x1].astype(np.float32)
   source[y0:y1,x0:x1]=np.uint8(dst*(1-alpha)+pred*alpha)
 for roi,q,a in repairs:
  # Reconstruct only a removed-label surface from that same surface's unlettered pixels.
  if a['role']=='layer':sample=region(q,(.08,.85,.92,.96))
  else:sample=region(q,(.87,.020,.96,.068))
  pixels=frame[sample>0]
  color=np.median(pixels,axis=0) if len(pixels)>4 else np.array([16,24,27])
  yy0=float(q[:,1].min());hh=max(float(np.ptp(q[:,1])),1)
  shade=np.clip((YY-yy0)/hh,0,1)*1.2
  fill=np.clip(color[None,None,:]-shade[:,:,None],0,255).astype(np.uint8)
  source[roi>0]=fill[roi>0];mask=cv2.bitwise_or(mask,roi)
 return source,mask,protected

# Canonical material maps only. Source UI is never resampled/warped to fit a new camera.
CW,CH=800,532
Y,X=np.mgrid[0:CH,0:CW].astype(np.float32)
def material_maps(q,time):
 M=cv2.getPerspectiveTransform(np.float32([[0,0],[CW-1,0],[CW-1,CH-1],[0,CH-1]]),q)
 # Rounded existing window edges, narrow soft bevel and restrained moving studio reflection.
 rounded=np.zeros((CH,CW),np.uint8);cv2.rectangle(rounded,(17,1),(CW-18,CH-2),255,-1);cv2.rectangle(rounded,(1,17),(CW-2,CH-18),255,-1)
 for x,y in [(18,18),(CW-19,18),(18,CH-19),(CW-19,CH-19)]:cv2.circle(rounded,(x,y),17,255,-1)
 distance=cv2.distanceTransform(rounded,cv2.DIST_L2,3)
 fade=np.clip(distance/3,0,1)
 angle=(q[1,1]-q[0,1])/max(np.linalg.norm(q[1]-q[0]),1)
 streak_center=.32+.18*np.sin(time*.48+angle*4)
 streak=np.exp(-((X/CW-streak_center-.16*Y/CH)/.23)**2)
 wash=(.015+.022*streak)*fade
 edge=np.exp(-((distance-2.8)/1.6)**2)*(.035+.07*(1-Y/CH))
 inner=np.exp(-((distance-7)/2.8)**2)*.012
 warp=lambda im:cv2.warpPerspective(im.astype(np.float32),M,(W,H),flags=cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT)
 return warp(fade),warp(wash),warp(edge+inner)

def glass(frame,items,time):
 cleaned,text_mask,protected=cleanup(frame,items)
 result=cleaned.astype(np.float32)
 panels=np.zeros((H,W),np.uint8)
 for _,q,_ in items:panels=cv2.bitwise_or(panels,poly_mask(q))
 # A low-frequency clean plate is inferred strictly from surrounding pixels in this same footage frame.
 # Hidden background is not claimed to be recovered exactly; it supplies only frosted color/reflection.
 tiny=cv2.resize(cleaned,(160,90),interpolation=cv2.INTER_AREA)
 tm=cv2.resize(panels,(160,90),interpolation=cv2.INTER_NEAREST)
 plate=cv2.inpaint(tiny,tm,5,cv2.INPAINT_TELEA)
 plate=cv2.resize(cv2.GaussianBlur(plate,(0,0),8.0),(W,H),interpolation=cv2.INTER_CUBIC).astype(np.float32)
 changed=text_mask.copy()
 # Existing background does not change outside the typography repair and existing panel silhouettes.
 for a,q,confidence in items:
  opacity,wash,rim=material_maps(q,time)
  if opacity.max()<.01:continue
  if a['role']=='panel':
   for b,r,_ in items:
    if b['role']=='layer' and b['id'].startswith(a['id']+'-'):opacity*=1-poly_mask(r)/255.0;wash*=1-poly_mask(r)/255.0;rim*=1-poly_mask(r)/255.0
  detail=np.zeros((H,W),np.float32)
  surface=opacity
  gx=cv2.Sobel(opacity,cv2.CV_32F,1,0,ksize=3);gy=cv2.Sobel(opacity,cv2.CV_32F,0,1,ksize=3)
  refracted=cv2.remap(plate,XX+gx*2.0,YY+gy*2.0,cv2.INTER_LINEAR,borderMode=cv2.BORDER_REFLECT)
  alpha=(.19 if a['role']=='panel' else .23)*surface
  base=result*(1-alpha[:,:,None])+refracted*alpha[:,:,None]
  # Milk-glass scattering is subtle, neutral, and limited to the existing surface.
  milk=(.009*surface+wash*.7)[:,:,None]
  base=base*(1-milk)+np.array([238.,240.,242.])*milk
  coat=rim[:,:,None]
  base=base*(1-coat)+np.array([240.,242.,244.])*coat
  active=opacity>.002
  result[active]=base[active]
  changed[active]=255
 return np.uint8(np.clip(np.rint(result),0,255)),changed,text_mask

if __name__=='__main__':
 import argparse
 parser=argparse.ArgumentParser();parser.add_argument('--preview',action='store_true');args=parser.parse_args()
 cap=cv2.VideoCapture(str(ROOT/CONFIG['source']))
 for t in [5.2,8.9,12.9,16.9,20.9,24.9,28.9,32.9]:
  index=round(t*30);cap.set(cv2.CAP_PROP_POS_FRAMES,index);ok,frame=cap.read()
  if not ok:raise RuntimeError(t)
  out,changed,mask=glass(frame,active_tracks(index),t)
  assert np.array_equal(out[changed==0],frame[changed==0]),'Background changed outside edit masks'
  cv2.imwrite(str(ROOT/f'.cache/glass-footage/preview-{t:.1f}.jpg'),out,[cv2.IMWRITE_JPEG_QUALITY,96])
  cv2.imwrite(str(ROOT/f'.cache/glass-footage/mask-{t:.1f}.png'),mask)
 cap.release();print('Eight footage-only material previews and edit masks written.')
