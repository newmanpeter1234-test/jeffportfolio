"""Verify the actual delivered MP4 and export inspection frames, not just source code."""
from pathlib import Path
import json,subprocess,hashlib,cv2,numpy as np
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'.cache/glass-footage/verification';OUT.mkdir(parents=True,exist_ok=True)
path=ROOT/'public/media/cybersecurity-liquid-glass-loop.mp4'
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(path)],text=True))
v=[s for s in probe['streams']if s['codec_type']=='video'];assert len(v)==1
v=v[0];assert (v['width'],v['height'],v['avg_frame_rate'])==(1920,1080,'60/1')
assert 15<=float(probe['format']['duration'])<=19 and abs(float(probe['format']['duration'])-18)<.02
assert v['codec_name']=='h264'and v['pix_fmt']=='yuv420p'and int(v['nb_frames'])==1080
assert not any(s['codec_type']=='audio'for s in probe['streams'])
b=path.read_bytes();assert b.find(b'moov')<b.find(b'mdat')
cap=cv2.VideoCapture(str(path));count=0;first=None;previous=None;last=None;means=[];diff=[]
while True:
 ok,frame=cap.read()
 if not ok:break
 small=cv2.resize(frame,(160,90),interpolation=cv2.INTER_AREA);mean=float(small.mean());assert mean>1,('Blank frame',count)
 if first is None:first=small.copy()
 if previous is not None:diff.append(float(np.abs(small.astype(float)-previous.astype(float)).mean()))
 if count%30==0:cv2.imwrite(str(OUT/f'frame-{count:04d}.jpg'),cv2.resize(frame,(960,540)),[cv2.IMWRITE_JPEG_QUALITY,95])
 previous=small;last=small;means.append(mean);count+=1
cap.release();assert count==1080
seam=float(np.abs(first.astype(float)-last.astype(float)).mean());assert seam<3,('Visible boundary discontinuity',seam)
source=ROOT/'public/media/cybersecurity-showreel.mp4';assert hashlib.sha256(source.read_bytes()).hexdigest()=='d748a3145926c4e4f2586c0a6704fa6e8c450238be06ee15bd023c1545a45132'
report={'duration':float(probe['format']['duration']),'width':1920,'height':1080,'fps':60,'decodedFrames':count,'audioStreams':0,'blankFrames':0,'faststart':True,'codec':v['codec_name'],'profile':v.get('profile'),'pixelFormat':v['pix_fmt'],'colorSpace':v.get('color_space'),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'sourcePreserved':True,'nativeSource':'720p/30fps','delivery':'1080p/60fps upscale and optical-flow interpolation of existing footage','loopSeamMeanAbsoluteRGBDifferenceAt160x90':seam,'minimumFrameMean':min(means),'maximumAdjacentFrameDifference':max(diff),'reviewFrames':36}
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
