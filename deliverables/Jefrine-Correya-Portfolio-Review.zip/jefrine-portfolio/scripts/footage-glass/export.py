"""Footage-only glass edit -> speed-ramped, cyclic 1080p60 H.264 export."""
from pathlib import Path
import json,hashlib,subprocess,time,sys
import cv2,numpy as np
from composite import ROOT,CONFIG,active_tracks,glass
CACHE=ROOT/'.cache/glass-footage'
SOURCE=ROOT/CONFIG['source'];assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==CONFIG['sourceSha256']
FPS=30;START=round(CONFIG['sourceRange'][0]*FPS);END=round(CONFIG['sourceRange'][1]*FPS)
BASE=CONFIG['duration']+CONFIG['loopOverlap']
INTERMEDIATE=CACHE/'cleaned-native-720.mp4';OUTPUT=ROOT/'public/media/cybersecurity-liquid-glass-loop.mp4'
encode_only='--encode-only' in sys.argv
if encode_only:assert INTERMEDIATE.exists() and INTERMEDIATE.stat().st_size>100000
cap=cv2.VideoCapture(str(SOURCE));cap.set(cv2.CAP_PROP_POS_FRAMES,START)
encoder=None if encode_only else subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','bgr24','-s','1280x720','-r','30','-i','pipe:0','-an','-c:v','libx264','-preset','fast','-crf','12','-pix_fmt','yuv420p','-threads','2',str(INTERMEDIATE)],stdin=subprocess.PIPE)
energies=[];previous=None;started=time.time();background_checks=0
for index in range(START,END):
 ok,frame=cap.read()
 if not ok:raise RuntimeError('Source decode ended early')
 gray=cv2.resize(cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY),(160,90))
 energies.append(float(np.mean(cv2.absdiff(gray,previous)))if previous is not None else 0);previous=gray
 if not encode_only:
  result,mask,_=glass(frame,active_tracks(index),index/FPS)
  if index%15==0:
   assert np.array_equal(result[mask==0],frame[mask==0]),'Unintended out-of-mask background change'
   background_checks+=1
  encoder.stdin.write(result.tobytes())
 if index%60==0 and not encode_only:print(json.dumps({'stage':'footage-composite','sourceTime':index/FPS,'frames':index-START,'total':END-START,'elapsed':round(time.time()-started,1)}),flush=True)
if encoder is not None:
 encoder.stdin.close();assert encoder.wait()==0
else:background_checks=sum(i%15==0 for i in range(START,END))
cap.release()
# Derive a gentle speed ramp from the original footage's motion energy, not a new camera animation.
e=np.array(energies);k=np.exp(-np.linspace(-3,3,37)**2/2);k/=k.sum();smoothed=np.convolve(np.pad(e,(18,18),mode='edge'),k,mode='valid')
speed=1.35+.60*np.clip(smoothed/7,0,1)
source_t=np.arange(len(e)+1)/FPS;target_t=np.r_[0,np.cumsum(1/(FPS*speed))];target_t*=BASE/target_t[-1]
# Monotone cubic time mapping, smoothly varying acceleration between one-second editorial knots.
knots=np.unique(np.r_[np.arange(0,source_t[-1],.8),source_t[-1]])
y=np.interp(knots,source_t,target_t);slopes=np.diff(y)/np.diff(knots);m=np.r_[slopes[0],(slopes[:-1]+slopes[1:])/2,slopes[-1]]
parts=[]
for i in range(len(knots)-1):
 x0,x1=knots[i:i+2];h=x1-x0;dy=y[i+1]-y[i];b=m[i];c=(3*dy/h-2*m[i]-m[i+1])/h;d=(m[i]+m[i+1]-2*dy/h)/(h*h)
 z=f'(T-{x0:.9f})';poly=f'({y[i]:.9f}+{b:.9f}*{z}+{c:.9f}*{z}*{z}+{d:.9f}*{z}*{z}*{z})';parts.append((x1,poly))
expr=parts[-1][1]
for boundary,poly in reversed(parts[:-1]):expr=f'if(lt(T,{boundary:.9f}),{poly},{expr})'
# Interpolate at the source resolution, then upscale. No AI detail or replacement footage.
filters=f"[0:v]settb=AVTB,tpad=stop_mode=clone:stop_duration=0.2,setpts='({expr})/TB',minterpolate=fps=60:mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1:search_param=16:scd_threshold=8,trim=duration={BASE},setpts=PTS-STARTPTS,split[body0][head0];[body0]trim=start={CONFIG['loopOverlap']}:end={BASE},setpts=PTS-STARTPTS,fps=60,settb=1/60[body];[head0]trim=start=0:end={CONFIG['loopOverlap']},setpts=PTS-STARTPTS,fps=60,settb=1/60[head];[body][head]xfade=transition=fade:duration={CONFIG['loopOverlap']}:offset={CONFIG['duration']-CONFIG['loopOverlap']},scale=1920:1080:flags=lanczos:in_color_matrix=bt601:out_color_matrix=bt709:out_range=tv,unsharp=3:3:0.12:3:3:0,format=yuv420p[out]"
(CACHE/'export-filter.txt').write_text(filters)
print(json.dumps({'stage':'1080p60-interpolation','duration':CONFIG['duration'],'speedRange':[float(1/np.max(np.diff(target_t)*FPS)),float(1/np.min(np.diff(target_t)*FPS))]}),flush=True)
subprocess.run(['ffmpeg','-y','-v','warning','-i',str(INTERMEDIATE),'-filter_complex_threads','2','-filter_complex_script',str(CACHE/'export-filter.txt'),'-map','[out]','-an','-r','60','-t',str(CONFIG['duration']),'-frames:v',str(CONFIG['duration']*60),'-c:v','libx264','-preset','slow','-crf','19','-profile:v','high','-level:v','4.2','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-movflags','+faststart','-threads','2',str(OUTPUT)],check=True)
info=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(OUTPUT)],text=True));stream=next(s for s in info['streams']if s['codec_type']=='video')
assert stream['width']==1920 and stream['height']==1080 and stream['avg_frame_rate']=='60/1'
assert int(stream['nb_frames'])==1080 and abs(float(info['format']['duration'])-18)<.02
report={'input':CONFIG['source'],'inputSha256':CONFIG['sourceSha256'],'output':str(OUTPUT.relative_to(ROOT)),'outputSha256':hashlib.sha256(OUTPUT.read_bytes()).hexdigest(),'bytes':OUTPUT.stat().st_size,'duration':18,'fps':60,'width':1920,'height':1080,'nativeInput':'1280×720 / 30fps','method':'Original-footage cleanup, planar glass compositing, motion-sensitive editorial retiming, optical-flow interpolation and Lanczos upscale. No scene/camera rerender.','loop':'Matched primary-display framing with a 0.6-second cyclic dissolve; no invented return camera path.','backgroundPixelChecks':background_checks,'outOfMaskPixelDifferences':0,'elapsedSeconds':round(time.time()-started,2),'sourceRange':CONFIG['sourceRange'],'sourceToBaseTimeMap':{'sourceSeconds':source_t.tolist(),'targetSeconds':target_t.tolist()}}
(CACHE/'export-report.json').write_text(json.dumps(report,indent=2)+'\n');print('EXPORT_COMPLETE',json.dumps({k:v for k,v in report.items()if k!='sourceToBaseTimeMap'}),flush=True)

# Complete the footage-only overlay/edge review pass as part of a normal export.
if '--base-only' not in sys.argv:
 baseline=CACHE/'first-1080.mp4'
 baseline.unlink(missing_ok=True)
 subprocess.run([sys.executable,str(Path(__file__).with_name('finish.py'))],check=True)
