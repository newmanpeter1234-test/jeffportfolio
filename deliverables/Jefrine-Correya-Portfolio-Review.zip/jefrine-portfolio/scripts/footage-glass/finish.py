"""Final footage-derived edge/overlay pass. Restores original background around the graded panes."""
from pathlib import Path
from collections import OrderedDict
import json,cv2,numpy as np,subprocess,time,hashlib
from composite import ROOT,CONFIG,TRACKS,active_tracks,poly_mask,region
CACHE=ROOT/'.cache/glass-footage'
DEST=ROOT/'public/media/cybersecurity-liquid-glass-loop.mp4'
BASE=CACHE/'first-1080.mp4'
if not BASE.exists():DEST.rename(BASE)
report=json.loads((CACHE/'export-report.json').read_text());mapping=report['sourceToBaseTimeMap'];xs=np.array(mapping['sourceSeconds']);ys=np.array(mapping['targetSeconds']);S=CONFIG['sourceRange'][0]
# Every template below comes from a frame of the one original source movie.
cap=cv2.VideoCapture(str(ROOT/CONFIG['source']));frames=OrderedDict();flows=OrderedDict()
read_index=-2
W,H=1280,720;yy,xx=np.mgrid[0:H,0:W].astype(np.float32)
cv2.setNumThreads(2)
def frame_at(index):
 global read_index
 index=int(np.clip(index,0,1229))
 if index not in frames:

  if index!=read_index+1:cap.set(cv2.CAP_PROP_POS_FRAMES,index)
  ok,im=cap.read();read_index=index
  if not ok:raise RuntimeError(index)
  frames[index]=im
  if len(frames)>48:frames.popitem(last=False)
 return frames[index]
def original(time):
 n=int(np.floor(time*30));a=float(time*30-n);f=frame_at(n);g=frame_at(n+1)
 if a<.002:return f.copy(),n,a
 if n not in flows:
  fa=cv2.cvtColor(cv2.resize(f,(320,180)),cv2.COLOR_BGR2GRAY);fb=cv2.cvtColor(cv2.resize(g,(320,180)),cv2.COLOR_BGR2GRAY)
  ab=cv2.calcOpticalFlowFarneback(fa,fb,None,.5,3,17,3,5,1.1,0);ba=cv2.calcOpticalFlowFarneback(fb,fa,None,.5,3,17,3,5,1.1,0)
  flows[n]=(cv2.resize(ab,(W,H))*4,cv2.resize(ba,(W,H))*4)
  if len(flows)>6:flows.popitem(last=False)
 ab,ba=flows[n];af=cv2.remap(f,xx-a*ab[:,:,0],yy-a*ab[:,:,1],cv2.INTER_LINEAR,borderMode=cv2.BORDER_REFLECT);bf=cv2.remap(g,xx-(1-a)*ba[:,:,0],yy-(1-a)*ba[:,:,1],cv2.INTER_LINEAR,borderMode=cv2.BORDER_REFLECT)
 return cv2.addWeighted(af,1-a,bf,a,0),n,a

def quad_for(name,n,a):
 d=TRACKS[name];p=d.get(str(n));q=d.get(str(n+1))
 if not p:return None
 pa=np.float32(p['quad']);return pa if not q else pa*(1-a)+np.float32(q['quad'])*a

# Source-only stencils precisely remove the stationary film captions, including overlap with a panel.
HUD=[];NOTE={}
for p in CONFIG['anchors'][:8]:
 im=frame_at(round(p['time']*30));gray=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY);m=np.zeros((H,W),np.uint8)
 for x1,y1,x2,y2,threshold in [(38,572,950,641,65),(38,640,945,675,40),(940,646,1246,673,35)]:m[y1:y2,x1:x2]=(gray[y1:y2,x1:x2]>threshold).astype(np.uint8)*255
 union=m.copy()
 for dy in range(1,11):union[dy:]=cv2.bitwise_or(union[dy:],m[:-dy])
 HUD.append(cv2.dilate(union,np.ones((5,5),np.uint8)))
for p in CONFIG['anchors'][8:]:
 if p['detail']=='native':continue
 im=frame_at(round(p['time']*30));q=np.float32(p['quad']);M=cv2.getPerspectiveTransform(q,np.float32([[0,0],[599,0],[599,199],[0,199]]));rect=cv2.warpPerspective(im,M,(600,200));gr=cv2.cvtColor(rect,cv2.COLOR_BGR2GRAY);m=(gr>70).astype(np.uint8)*255
 m[:7]=0;m[-8:]=0;m[:,:8]=0;m[:,-8:]=0
 if p['detail']=='code':m[45:]=0
 NOTE[p['id']]=cv2.dilate(m,np.ones((5,5),np.uint8))

def stencil_fix(image,n,a,time):
 scene=int(np.clip(np.floor((time-3.25)/4),0,7));out=image.copy();mask=HUD[scene].copy()
 # Remove header and footer glyphs everywhere, including where the original HUD crossed chrome.
 gr=cv2.cvtColor(out,cv2.COLOR_BGR2GRAY)
 for x1,y1,x2,y2 in [(41,27,245,65),(1047,29,1241,62),(38,686,1244,708)]:
  local=gr[y1:y2,x1:x2].astype(float);signal=((local-cv2.GaussianBlur(local,(0,0),3))>2).astype(np.uint8)*255
  mask[y1:y2,x1:x2]|=cv2.dilate(signal,np.ones((5,5),np.uint8))
 protected=np.zeros((H,W),np.uint8)
 for p in CONFIG['anchors'][:8]:
  q=quad_for(p['id'],n,a)
  if q is not None:protected|=poly_mask(q)
 f=out.astype(float);lo=f.min(axis=2);hi=f.max(axis=2);ratio=f[:,:,2]/np.maximum(np.maximum(f[:,:,0],f[:,:,1]),1)
 gray=cv2.cvtColor(out,cv2.COLOR_BGR2GRAY).astype(float);contrast=gray-cv2.GaussianBlur(gray,(0,0),12)
 num=((ratio>.48)&(ratio<.80)&(f[:,:,1]>f[:,:,2]+1)&(f[:,:,0]>f[:,:,2]+.5)&(contrast>1)&(gray>9)&(protected==0)).astype(np.uint8)*255
 num=cv2.morphologyEx(num,cv2.MORPH_CLOSE,np.ones((5,5),np.uint8));cs,_=cv2.findContours(num,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
 for c in cs:
  x,y,w,h=cv2.boundingRect(c)
  if 20<h<235 and 5<w<230 and cv2.contourArea(c)>25:
   x0=max(0,x-9);x1=min(W,x+w+9);y0=max(0,y-9);y1=min(H,y+h+9);local=np.zeros((H,W),np.uint8);local[y0:y1,x0:x1]=255;local[protected>0]=0;mask|=local
 if mask.any():out=cv2.inpaint(out,mask,4,cv2.INPAINT_TELEA)
 return out

def source_time(base_t):return S+float(np.interp(base_t,ys,xs))
input_cap=cv2.VideoCapture(str(BASE));encoder=subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','bgr24','-s','1280x720','-r','60','-i','pipe:0','-an','-vf','scale=1920:1080:flags=lanczos:out_color_matrix=bt709:out_range=tv,format=yuv420p','-c:v','libx264','-preset','slow','-crf','18','-profile:v','high','-level:v','4.2','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-movflags','+faststart','-threads','2',str(DEST)],stdin=subprocess.PIPE)
started=time.time();repairs=0
for i in range(1080):
 ok,encoded=input_cap.read()
 if not ok:raise RuntimeError('Incomplete first pass')
 base=cv2.resize(encoded,(W,H),interpolation=cv2.INTER_AREA);t=i/60
 tail_t=source_time(t+.6);fresh,n,a=original(tail_t);q=quad_for(CONFIG['anchors'][int(np.clip(np.floor((tail_t-3.25)/4),0,7))]['id'],n,a)
 inside=np.zeros((H,W),np.uint8)if q is None else poly_mask(q)
 if t>=17.4:
  blend=(t-17.4)/.6;head_t=source_time(t-17.4);head,hn,ha=original(head_t);fresh=cv2.addWeighted(fresh,1-blend,head,blend,0)
  hq=quad_for('astra',hn,ha)
  if hq is not None:inside|=poly_mask(hq)
 # Keep the carefully graded dashboard, restore only surrounding original footage so no tracking wedge survives.
 alpha=cv2.GaussianBlur(inside.astype(np.float32)/255,(0,0),1.0)[:,:,None]
 out=np.uint8(np.clip(base*alpha+fresh*(1-alpha),0,255))
 # During layer entrance/exit, an opacity-fading label must not turn into an opaque tracked polygon.
 if t<17.4:
  for p in CONFIG['anchors'][8:]:
   if not p['range'][0]-.15<=tail_t<=p['range'][1]+.1:continue
   phase=tail_t-(3.25+4*(CONFIG['anchors'].index(p)%8))
   bad=(phase<1.05 or phase>3.05)
   lq=quad_for(p['id'],n,a)
   if lq is None or not bad:continue
   repair=poly_mask(lq);repair=cv2.dilate(repair,np.ones((17,17),np.uint8))
   # Original pixels, original perspective; no new panel/return-camera render.
   target=fresh.astype(np.float32)*.94+np.array([12,17,18],np.float32)*.06
   if p['id'] in NOTE:
    M=cv2.getPerspectiveTransform(np.float32([[0,0],[599,0],[599,199],[0,199]]),lq)
    words=cv2.warpPerspective(NOTE[p['id']],M,(W,H));target=cv2.inpaint(np.uint8(target),words,4,cv2.INPAINT_TELEA).astype(float)
   soft=np.clip(cv2.distanceTransform(repair,cv2.DIST_L2,3)/6,0,1)[:,:,None]
   out=np.uint8(np.clip(out*(1-soft)+target*soft,0,255));repairs+=1
 out=stencil_fix(out,n,a,tail_t)
 if t>=17.4:out=stencil_fix(out,hn,ha,head_t)
 encoder.stdin.write(out.tobytes())
 if i%120==0:print(json.dumps({'stage':'final-overlay-review','frame':i,'of':1080,'elapsed':round(time.time()-started,1)}),flush=True)
encoder.stdin.close();assert encoder.wait()==0;input_cap.release();cap.release()
meta={'method':'Source-footage background restoration, exact source-caption stencils and localized original-pixel layer-edge repair','frames':1080,'layerEdgeRepairs':repairs,'sha256':hashlib.sha256(DEST.read_bytes()).hexdigest(),'bytes':DEST.stat().st_size,'seconds':round(time.time()-started,2)}
(CACHE/'finish-report.json').write_text(json.dumps(meta,indent=2)+'\n');print('FINISH_COMPLETE',json.dumps(meta),flush=True)

if '--without-polish' not in __import__('sys').argv:
 (CACHE/'before-numeral-polish.mp4').unlink(missing_ok=True)
 subprocess.run([__import__('sys').executable,str(Path(__file__).with_name('polish.py'))],check=True)
