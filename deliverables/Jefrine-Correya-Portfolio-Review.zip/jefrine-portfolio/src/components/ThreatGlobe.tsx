import { profile } from '../data/content';
import { useEffect, useRef, useState } from 'react';
import { RotateCw, MoveHorizontal } from 'lucide-react';
import * as THREE from 'three';
import land from '../data/land-points.json';
import { asset, useExperience } from '../hooks/useExperience';

function position(lat: number, lng: number, radius = 1.4) {
  const phi = THREE.MathUtils.degToRad(lat), theta = THREE.MathUtils.degToRad(lng);
  return new THREE.Vector3(radius * Math.cos(phi) * Math.sin(theta), radius * Math.sin(phi), radius * Math.cos(phi) * Math.cos(theta));
}
const locations = [[profile.latitude, profile.longitude], [1.35, 103.82], [35.68, 139.69], [51.51, -.12], [40.71, -74], [-33.87, 151.21], [19.07, 72.87]];

export function ThreatGlobe() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rotateRef = useRef<(() => void) | null>(null);
  const [failed, setFailed] = useState(false);
  const { motion } = useExperience();
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || failed) return;
    let renderer: THREE.WebGLRenderer;
    try { renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true, powerPreference: 'low-power' }); } catch { setFailed(true); return; }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.6));
    renderer.setClearColor(0x000000, 0);
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(42, 1, .1, 30);
    camera.position.set(0, 0, 5.1);
    const world = new THREE.Group(); world.rotation.set(.08, -1.36, -.12); scene.add(world);
    world.add(new THREE.Mesh(new THREE.SphereGeometry(1.397, 64, 48), new THREE.MeshBasicMaterial({ color: 0x0c1812 })));
    const atmosphere = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false,
      uniforms: { color: { value: new THREE.Color('#45674b') } },
      vertexShader: 'varying vec3 vNormal; varying vec3 vPosition; void main(){vNormal=normalize(normalMatrix*normal); vec4 mv=modelViewMatrix*vec4(position,1.0);vPosition=mv.xyz;gl_Position=projectionMatrix*mv;}',
      fragmentShader: 'uniform vec3 color; varying vec3 vNormal; varying vec3 vPosition; void main(){float rim=pow(1.0-max(dot(normalize(vNormal),normalize(-vPosition)),0.0),2.7);gl_FragColor=vec4(color,rim*.4);}',
    });
    world.add(new THREE.Mesh(new THREE.SphereGeometry(1.411, 64, 48), atmosphere));
    const points = new Float32Array(land.length * 3);
    land.forEach(([lat, lng], i) => position(lat, lng, 1.418).toArray(points, i * 3));
    const geometry = new THREE.BufferGeometry(); geometry.setAttribute('position', new THREE.BufferAttribute(points, 3));
    const pointMaterial = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false,
      uniforms: { pixelRatio: { value: Math.min(window.devicePixelRatio, 1.6) } },
      vertexShader: 'uniform float pixelRatio; varying float vAlpha; void main(){vec4 mv=modelViewMatrix*vec4(position,1.0); vec3 n=normalize(normalMatrix*normalize(position));float facing=max(dot(n,normalize(-mv.xyz)),0.0);vAlpha=.26+.74*facing;gl_PointSize=2.45*pixelRatio*(4.1/-mv.z);gl_Position=projectionMatrix*mv;}',
      fragmentShader: 'varying float vAlpha; void main(){float d=length(gl_PointCoord-vec2(.5));float a=1.0-smoothstep(.3,.5,d);if(a<.01)discard;gl_FragColor=vec4(.39,.57,.4,a*vAlpha);}',
    });
    world.add(new THREE.Points(geometry, pointMaterial));
    const gridMaterial = new THREE.LineBasicMaterial({ color: 0x66826a, transparent: true, opacity: .105 });
    for (let lat = -60; lat <= 60; lat += 30) {
      const pts = Array.from({ length: 181 }, (_, i) => position(lat, i * 2 - 180, 1.413));
      world.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), gridMaterial));
    }
    for (let lng = 0; lng < 360; lng += 30) {
      const pts = Array.from({ length: 91 }, (_, i) => position(i * 2 - 90, lng, 1.413));
      world.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), gridMaterial));
    }
    const orbitMaterial = new THREE.LineBasicMaterial({ color: 0x739665, transparent: true, opacity: .27 });
    function orbit(radius: number, tilt: number, z: number, dash = false) {
      const pts = Array.from({ length: 201 }, (_, i) => new THREE.Vector3(Math.cos(i / 200 * Math.PI * 2) * radius, Math.sin(i / 200 * Math.PI * 2) * radius, 0));
      const mat = dash ? new THREE.LineDashedMaterial({ color: 0x657c61, transparent: true, opacity: .3, dashSize: .008, gapSize: .04 }) : orbitMaterial;
      const line = new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), mat); line.rotation.x = tilt; line.rotation.z = z;
      if (dash) line.computeLineDistances(); scene.add(line);
    }
    orbit(1.85, 1.11, -.35); orbit(1.68, -.97, -.63); orbit(1.87, 0, 0, true);
    const nodeMaterial = new THREE.MeshBasicMaterial({ color: 0xc7f891 });
    const pulseMaterial = new THREE.MeshBasicMaterial({ color: 0xc7f891, transparent: true, opacity: .5, side: THREE.DoubleSide, depthWrite: false });
    const rings: THREE.Mesh[] = [];
    locations.forEach(([lat, lng]) => {
      const pos = position(lat, lng, 1.43);
      const node = new THREE.Mesh(new THREE.SphereGeometry(.027, 12, 8), nodeMaterial); node.position.copy(pos); world.add(node);
      const ring = new THREE.Mesh(new THREE.RingGeometry(.047, .052, 32), pulseMaterial); ring.position.copy(pos); ring.lookAt(pos.clone().multiplyScalar(2)); world.add(ring); rings.push(ring);
    });
    const arcMaterial = new THREE.LineBasicMaterial({ color: 0xa4ce75, transparent: true, opacity: .5 });
    const arcs: THREE.CatmullRomCurve3[] = [];
    const particles: THREE.Mesh[] = [];
    for (let i = 1; i < locations.length; i++) {
      const start = position(locations[i][0], locations[i][1], 1.432), end = position(locations[0][0], locations[0][1], 1.432);
      const lift = 1.59 + start.distanceTo(end) * .13;
      const controls = [start, start.clone().lerp(end, .25).normalize().multiplyScalar(lift), start.clone().lerp(end, .5).normalize().multiplyScalar(lift + .04), start.clone().lerp(end, .75).normalize().multiplyScalar(lift), end];
      const curve = new THREE.CatmullRomCurve3(controls); arcs.push(curve);
      world.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(curve.getPoints(80)), arcMaterial));
      const particle = new THREE.Mesh(new THREE.SphereGeometry(.019, 8, 6), nodeMaterial); world.add(particle); particles.push(particle);
    }
    // Atmospheric markers are a visual motif, not real threat statistics.
    const starPos: number[] = [];
    for (let i = 0; i < 65; i++) { const a = i * 2.39996, r = 1.95 + (i % 5) * .12; starPos.push(Math.cos(a) * r, Math.sin(a) * r, -.25); }
    const starGeo = new THREE.BufferGeometry(); starGeo.setAttribute('position', new THREE.Float32BufferAttribute(starPos, 3));
    scene.add(new THREE.Points(starGeo, new THREE.PointsMaterial({ color: 0x81937d, size: .01, transparent: true, opacity: .3 })));
    let frame = 0, visible = true, disposed = false, dragging = false, lastX = 0, lastY = 0, lastTime = 0;
    const render = () => { if (!disposed) renderer.render(scene, camera); };
    function animate(time: number) {
      frame = 0; if (disposed || !visible || document.hidden || !motion) return;
      const delta = Math.min((time - lastTime) / 1000, .03); lastTime = time;
      if (!dragging) world.rotation.y += delta * .055;
      rings.forEach((r, i) => r.scale.setScalar(1 + (Math.sin(time * .0015 + i) + 1) * .18));
      particles.forEach((p, i) => p.position.copy(arcs[i].getPoint((time * .00009 + i * .18) % 1)));
      render(); frame = requestAnimationFrame(animate);
    }
    function start() { if (motion && visible && !document.hidden && !frame && !disposed) { lastTime = performance.now(); frame = requestAnimationFrame(animate); } }
    function resize() { const rect = canvas!.getBoundingClientRect(); if (!rect.width || !rect.height) return; camera.aspect = rect.width / rect.height; camera.updateProjectionMatrix(); renderer.setSize(rect.width, rect.height, false); render(); }
    const resizeObserver = new ResizeObserver(resize); resizeObserver.observe(canvas); resize();
    const observer = new IntersectionObserver(([entry]) => { visible = entry.isIntersecting; if (visible) start(); else { cancelAnimationFrame(frame); frame = 0; } }, { threshold: .01 }); observer.observe(canvas);
    const visibility = () => { if (document.hidden) { cancelAnimationFrame(frame); frame = 0; } else start(); }; document.addEventListener('visibilitychange', visibility);
    const down = (e: PointerEvent) => { dragging = true; lastX = e.clientX; lastY = e.clientY; if (e.pointerType === 'mouse') canvas.setPointerCapture(e.pointerId); };
    const move = (e: PointerEvent) => { if (!dragging) return; const dx = e.clientX - lastX, dy = e.clientY - lastY; if (e.pointerType === 'touch' && Math.abs(dy) > Math.abs(dx)) return; world.rotation.y += dx * .005; world.rotation.x = THREE.MathUtils.clamp(world.rotation.x + dy * .0015, -.3, .3); lastX = e.clientX; lastY = e.clientY; render(); };
    const up = () => { dragging = false; };
    const keydown = (e: KeyboardEvent) => { if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return; e.preventDefault(); world.rotation.y += e.key === 'ArrowRight' ? .15 : -.15; render(); };
    const lost = (e: Event) => { e.preventDefault(); setFailed(true); };
    canvas.addEventListener('pointerdown', down); canvas.addEventListener('pointermove', move); canvas.addEventListener('pointerup', up); canvas.addEventListener('pointercancel', up); canvas.addEventListener('keydown', keydown); canvas.addEventListener('webglcontextlost', lost);
    rotateRef.current = () => { world.rotation.y += .25; render(); };
    particles.forEach((p, i) => p.position.copy(arcs[i].getPoint(i * .15))); render(); start();
    return () => {
      disposed = true; cancelAnimationFrame(frame); observer.disconnect(); resizeObserver.disconnect(); document.removeEventListener('visibilitychange', visibility);
      canvas.removeEventListener('pointerdown', down); canvas.removeEventListener('pointermove', move); canvas.removeEventListener('pointerup', up); canvas.removeEventListener('pointercancel', up); canvas.removeEventListener('keydown', keydown); canvas.removeEventListener('webglcontextlost', lost); rotateRef.current = null;
      const geometries = new Set<THREE.BufferGeometry>(), materials = new Set<THREE.Material>();
      scene.traverse(obj => { const mesh = obj as THREE.Mesh; if (mesh.geometry) geometries.add(mesh.geometry); if (mesh.material) (Array.isArray(mesh.material) ? mesh.material : [mesh.material]).forEach(m => materials.add(m)); });
      geometries.forEach(g => g.dispose()); materials.forEach(m => m.dispose()); renderer.dispose();
    };
  }, [motion, failed]);
  return <div className="threat-globe">
    <div className="globe-ambient" aria-hidden="true" />
    <div className="globe-top-meta"><span><span className="status-dot" />THREAT SURFACE</span><span>GLOBAL PERSPECTIVE / LOCAL FOCUS</span></div>
    {failed ? <img className="globe-fallback" src={asset('/images/globe-fallback.svg')} alt="Illustrative point-cloud globe with orbital lines" /> : <canvas ref={canvasRef} className="globe-canvas" tabIndex={0} aria-label="Illustrative security globe, not live threat data. Drag, or use left and right arrow keys, to rotate." data-cursor="DRAG" />}
    <div className="globe-callout callout-one"><span className="callout-node" /><span>DETECT THE SIGNAL</span><span className="callout-coord">T1110</span></div>
    <div className="globe-callout callout-two"><span className="callout-node" /><span>CONNECT THE CONTEXT</span></div>
    <div className="globe-home"><span className="globe-home-cross">+</span><span>DOHA, QATAR<br /><span>25.29° N · 51.53° E</span></span></div>
    <div className="globe-bottom-meta"><span>ILLUSTRATIVE TOPOLOGY<br /><span className="muted">NOT LIVE THREAT DATA</span></span><button className="globe-rotate" onClick={() => rotateRef.current?.()} aria-label="Rotate illustrative globe" disabled={failed}><MoveHorizontal size={14} /><span>DRAG TO EXPLORE</span><RotateCw size={12} /></button></div>
  </div>;
}
