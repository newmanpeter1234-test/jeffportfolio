# Jefrine Correya — Beyond the noise

A researched, interactive cybersecurity portfolio. React 19 + TypeScript + Vite, GSAP, and custom CSS. No analytics, embedded API keys, backend scanner, or invented performance claims.

## Review status / safety

- Target repository: **jeff-1217/Portfolio**.
- Working branch: **`feat/liquid-glass-footage-edit`**, based on the completed hero release `93b8868`.
- Base: **`809388399e17c9e949f14ef201ece51701ec5816`**.
- Work was made locally on the feature branch. Main was not checked out or modified.
- **No remote push, remote pull request, or merge has been performed.** A separate review copy is manually hosted at https://jefrine-correya-portfolio.vercel.app in the existing approved Vercel project. The original domain and GitHub main are unchanged. See `docs/REVIEW-HANDOFF.md` for safe review instructions.
- A separate `jeffportfolio` public repository contains the current live site's newer content. The project uses that public material as a content source, but the working base remains the original `Portfolio` repository.

## Run locally

```bash
npm ci
npm run dev
```

Vite binds to `0.0.0.0:5173`; Arena's `.e2b.app` preview hosts are allowed. No browser-facing localhost API calls are made. All fonts, pictures, and land-point data are local.

```bash
npm run build          # TypeScript check and production build
npm run preview        # Local production preview (not a deployment)
npm run test:content   # Content/source-integrity assertions
npx playwright install --with-deps chromium
npm test               # Desktop/mobile functional + accessibility tests
```

The lockfile is committed. The production build is output to `dist/` (not committed). No CI deployment workflows have been added.

## The experience

- Cinematic eight-project film: 41-second offline-rendered Three.js camera journey and a dedicated 10.8-second three-project loop. Actual UI/report evidence, true spatial transitions, responsive posters, explicit controls and truthful scope labels. The website itself loads no live Three.js scene. See `docs/SPATIAL-SHOWREEL.md`.
- GSAP entrance / scroll reveals, animated project artwork, custom pointer feedback on fine-pointer devices, and interactive capability tabs.
- A three-scenario SOC investigation experience. All data is local and explicitly illustrative; no real URLs, IPs, or APIs are scanned.
- Searchable, category-filtered archive of **19 projects/labs**, with **19 evidence-linked case studies**.
- An expandable index of **all 26 public repositories** captured during research.
- Journey, credentials, contact, and content-provenance pages.
- Command / Control K quick access with keyboard navigation and focus management.
- Reduced-motion preference respected by default, plus a persistent manual motion switch. Offscreen and backgrounded video pauses. Mobile, reduced-motion and low-data settings default to a source-free poster; explicit play remains available.
- Local WOFF2 fonts, locally stored original photos/covers, route metadata, JSON-LD, sitemap, and a JavaScript-free résumé/contact fallback.
- Preview-first Document Room for the updated résumé, CICSA, EC-Council CSA, and experience letter. Optional PDF downloads appear only inside the viewer. The prior `/assets/jeffresume%20.pdf` URL serves the updated résumé too.
- Direct-send contact form using FormSubmit, with validation, a honeypot, a pending/duplicate-request guard, a timeout, and explicit sending/success/error states. Original visitor text is retained on errors. The owner activated delivery and confirmed a real received test email. Automated UI tests alone are not inbox-delivery proof. Form data is processed by the delivery service, not stored by this static website.

## Routes

| Route | Content |
| --- | --- |
| `/` | Overview, selected work, simulation, bio, toolkit, credentials, contact |
| `/projects` | Search/filter archive and full public repository index |
| `/projects/:slug` | Individual project case studies, scope, workflow, and evidence |
| `/journey` | Confirmed experience, training, education, skills, languages |
| `/credentials` | Two earned credentials, original certificate previews, an experience letter, and a separate learning goal |
| `/contact` | Email/LinkedIn/GitHub channels and a direct-send contact form (no phone card) |
| `/sources` | Content provenance and explicitly handled discrepancies |
| `/showreel` | On-demand 41-second project film, captions/transcript, eight real case/source links and download |

The isolated Vercel review copy uses SPA rewrites; static assets, including `media/`, bypass the HTML fallback. A Netlify rewrite file is also retained as configuration, not a claim of a Netlify deployment. Other static hosts must serve `index.html` for application routes while serving real files normally.

## Content maintenance

- `src/data/content.ts`: personal details, experience, original self-rated skills, credentials, and case studies.
- `src/data/repository-index.json`: public repository inventory.
- `docs/CONTENT-SOURCES.md`: research decisions and source differences.
- `public/documents/jefrine-correya-resume.pdf`: unmodified Qatar résumé supplied on 22 October 2026.
- `public/images/`: original photography and project covers, plus the generated geometric globe fallback.
- The original root `assets/`, `script.js`, and `style.css` remain in the repository as historical source material; they are not imported into the new application or emitted by Vite.

### Facts confirmed for this redesign

Current base: **Doha, Qatar** (Asia/Qatar, AST / UTC +03:00), explicitly confirmed on 22 October 2026. The uploaded Qatar résumé replaces the previous file. The experience letter confirms **Junior Cyber Security Analyst, Wahy Lab Solutions, 1 September 2025–29 May 2026**; role responsibilities follow the updated résumé. Original certificate issue dates: **CSA, 27 July 2025; CICSA v3, 11 July 2025**. CompTIA Security+ is an earlier learning goal, not an earned credential; its current status needs confirmation because it is absent from the new résumé.

No new job dates, certificate IDs, official badges, clients, incident counts, detection accuracy, or response-time statistics are invented. The IOC pipeline's approximately 80% effort reduction is attributed only as an author-reported README estimate. ASTRA is identified as a simulation. The SOC assistant's documented CrewAI architecture is distinguished from the current direct Python implementation.

## Standalone file preview

```bash
node scripts/make-standalone.mjs ./Jefrine-Correya-Portfolio.html
```

Builds a self-contained HTML file with embedded JavaScript, styles, fonts, photographs, PDF, and globe data. It uses memory navigation so every page works inside an opaque-origin, no-network file viewer. The production site uses normal browser routes instead. External demos, source links, email apps, clipboard access, and downloads depend on the browser / sandbox permissions; the site explains these boundaries rather than faking success.

## License / assets

The original résumé, photos, and project imagery were copied from Jefrine's own public portfolio/repositories for this requested redesign. Font OFL licenses are in `public/fonts/`. New project artwork is conceptual, implemented in SVG/CSS, and labelled accordingly. See `docs/THIRD-PARTY.md` for dependency and map-source attribution. No official certification badge or certificate scan has been fabricated.

## 22 October 2026 update

- [Latest QA](docs/QA-2026-10-22.md): 38 passing tests, two intentional skips, original-PDF integrity checks, modal accessibility, mobile layouts, and offline previews.
- [Prioritized portfolio review](docs/PORTFOLIO-REVIEW-2026-10-22.md).
- `src/data/documents.json`: four-document inventory, source hashes, readable text, page sizes and preview paths.
- `src/components/DocumentViewer.tsx`: preview-first, accessible Document Room.
- `src/document-viewer.css`: responsive viewer and screenshot-inspired native lime cursor.
- Regenerate previews after changing the original PDFs: `python -m pip install PyMuPDF Pillow`, then `python scripts/prepare-documents.py`. Review/update the expected source hashes in `scripts/check-content.mjs` only when intentionally replacing a document.

The user supplied the four original PDFs for public viewing. No official certificate or employment document has been generated or altered.

## Contact/cursor follow-up — 22 October 2026

- Desktop arrow reduced from 28×35 to 24×30 px, preserving its shape, lime color and text/touch fallbacks.
- Overview/header CTA now reads **Contact**, not Hire me.
- The phone card and unused profile phone field are removed. Original supplied PDFs are intentionally unchanged, including any contact details inside them.
- Main form button reads **Send mail** and submits directly to FormSubmit, not mailto. Direct email remains an explicit fallback.
- Sender-state tests intercept/mock the delivery endpoint; actual email activation/receipt must be confirmed separately by the owner.

Owner confirmation: the live contact test email arrived after activation on 22 October 2026. See `docs/QA-CONTACT-2026-10-22.md`: 48 full-suite tests plus 12 targeted public-site tests passed.

## Cinematic film maintenance

`npm run showreel:studio` starts the separate offline studio. `npm run showreel:render -- --mode=master --crf=25` and `npm run showreel:hero -- --crf=25` export sequentially; `npm run showreel:verify` checks the scene system. See `docs/SPATIAL-SHOWREEL.md` for complete M2-friendly commands, optional capture setup, source pins, privacy redactions, 84-pass QA and limitations. No video-generation toolchain enters the production runtime.

## Latest clean liquid-glass hero

The active homepage is an 18-second footage-only liquid-glass edit, delivered at 1920×1080 / 60 fps from the original 720p30 master. The original source/camera journey is retained; no new scene was rendered. The larger player has one small icon-only control and no visible chapter tabs/captions/film CTA. Muted autoplay is eligible on desktop and mobile, subject to motion/data/browser restrictions. The previous full film remains archived at `/showreel`. See `docs/LIQUID-GLASS-EDIT.md` for the exact method, upscaling distinction, render commands and QA.

## Native quality repair

Current branch: `fix/native-glass-quality`. With owner approval, the artifact-prone footage cleanup is superseded by a direct native 1920×1080/60fps export from the existing scene, same camera/environment and approved 18-second pacing. Editorial overlay cards are absent, rather than blanked out; browser UI captures are 2×/3× density. No optical-flow repair or upscaling stage is used in this export. The small-control autoplay hero remains unchanged. See `docs/NATIVE-QUALITY-REPAIR.md`.
