# Cinematic hero — audit, implementation and verification

22 October 2026 · dedicated branch `feat/cinematic-project-hero`, based on clean `fce634a`.

## Audit
- React 19 / TypeScript / Vite 7; React Router pages; existing GSAP reveal system, olive/near-black + lime design, local typography. No framework or design-system replacement is necessary.
- Home currently splits oversized brand typography and an illustrative Three.js globe. The globe has capped pixel ratio, visibility pause, pointer/keyboard rotation and disposal, but its module still imports ~480 KB of Three.js and constructs a WebGL renderer even when animation is disabled. A GPU globe alongside a video would compete for attention and rendering resources.
- Strongest relevant projects: ASTRA Monitor (actual Flask/Socket.IO dashboard and implemented table/detail interactions); SOC Threat Assistant (external API credentials required); Splunk/Wazuh labs (evidence/report driven, not independently deployable apps); URL detector (requires Google Safe Browsing and its error handling is not suitable for a truthful credential-free result recording). No invented results or dashboards will be substituted.
- ASTRA source inspected at public commit `ffa45993badc72b9683beb6e2c8a79fe00a3248d`. Its `/` dashboard, `#threats` navigation, pre-existing `THR-10234` / `THR-10235` sample rows, `showThreatDetails` and Bootstrap dismissal are real. Block/Escalate buttons have no implemented action and will not be demonstrated. A hard-coded model accuracy line and random telemetry must not be presented as measured security results.
- Existing routes, document viewer, direct-send contact form, responsive navigation, security/noindex and PDF response headers remain in scope for regression tests. Original site/domain/main must remain untouched.

## Plan
1. Capture ASTRA's genuine sample-alert table → detail panel → close-panel interaction as an approximately 10-second local-demo loop. Pause its random telemetry generator in a capture-only harness, preserve the existing fixture UI, and redact unverified accuracy/confidence values. Persistent labels state that this is a recorded sample workflow, not live activity.
2. Use Playwright for the real browser interaction/recording and FFmpeg for restrained camera movement and H.264/yuv420p/fast-start compression. Evaluate Remotion but do not add it: a single linear capture does not justify a second rendering framework or any production video dependencies.
3. Build a reusable, accessible browser-frame showcase with a real project/case-study link, source link, play/pause, clear provenance, poster fallback and concise workflow labels.
4. Preserve the globe motif using a small inline wireframe vector (rather than downloading the 207 KB legacy fallback artwork) as a subtle background accent. Do not initialize a second WebGL scene behind video.
5. Keep hero copy and CTAs independent of media. Use poster-first on mobile, slow connections, Save-Data and reduced motion; defer video source attachment; pause off-screen/in hidden tabs; handle blocked autoplay and media errors without breaking navigation.
6. Test real desktop/mobile rendering, fallback/network preferences, reduced motion, playback lifecycle, accessibility, existing routes and full suite. Publish only to the existing isolated review project after checks pass.

## Source / safety boundaries
The capture harness is not a new product feature. It stops random telemetry and redacts unsupported numerical claims, but does not invent threat data, API responses or actions. The original repository's existing sample rows/details remain explicitly demo fixtures. No secret files, private logs, real scan targets, external threat-intelligence APIs or credentials are used in the recording. GitHub's connected-app tool is unsupported here; public repository source was read via a public clone, with no remote write or PR claimed.

## Implemented result

The overview now leads with the real ASTRA interface in a reusable browser frame, alongside the existing “Beyond the noise.” identity, qualification, Doha location and primary CTAs. The near-black/olive/lime palette and local fonts remain intact. There is one project and one deliberate loop, not a distracting carousel.

The 10.8-second video shows the upstream sample table, an actual click opening THR-10234, inspection of its original context, and the implemented Close Investigation dismissal. Cursor positions/clicks come from the same browser actions. A restrained 1.5–3% camera movement returns to its starting scale; the table and pointer also return to their starting positions. Labels identify the recording as a local demo throughout.

The sample's IP, enrichment, status and response fields are **built-in fixture values**, not independent intelligence, real incidents or evidence of a working firewall action. The original random generator is paused. Unverified accuracy/confidence lines are redacted. No Block/Escalate action, AI command, generated alert or external scan result is demonstrated. The offscreen decorative ASTRA globe and unused status/activation controls are omitted in the capture harness only. No source project feature was implemented or changed to manufacture this demonstration.

Pinned source: https://github.com/jeff-1217/ASTRA-Monitor/tree/ffa45993badc72b9683beb6e2c8a79fe00a3248d

### Production behavior

- `HeroShowcase` accepts a typed project configuration: labels, source/case links, media, duration, poster phase and actual phase timings. The decorative browser chrome is separate from the real captured UI.
- The external responsive `<picture>` is the fallback, with no redundant video-poster fetch. No video source exists until playback is eligible. Text/CTAs never await media.
- Normal desktop playback is muted, inline and looping, deferred by 400 ms and only while sufficiently visible. Offscreen/hidden states pause. User pause is preserved.
- Reduced motion, global motion-off, mobile/coarse pointers, Save-Data, 2g/3g and reported downlink below 1.2 Mbps all default to the static poster. An explicit play gesture can opt into the recording. Changed preferences release the source.
- Blocked autoplay, failed media and a failed image have progressively simpler, accessible fallbacks. Project/source links remain usable. Workflow timing is generated alongside the media, not invented independently.
- A tiny inline wireframe globe/network accent preserves the motif with no WebGL, extra image download, live threat markers or made-up metrics. It stops rotating with motion-off/reduced motion.
- The source-free standalone/opaque-origin HTML deliberately remains poster-only. The MP4 is delivered separately and the live site provides playback.
- The Vercel SPA rewrite now excludes `media/`, preserving real MP4/JSON asset responses rather than accidentally returning `index.html`.

### Asset specifications

- MP4: **706,686 bytes**, **10.8 seconds**, **1152×720 / 30 fps**, **H.264 Main / level 3.1 / yuv420p**, no audio stream, `+faststart`.
- Desktop poster: **32,468 bytes**, **1152×720 WebP**.
- Mobile poster: **11,690 bytes**, **704×440 WebP**, full-panel framing with padding instead of clipping the action controls.
- Video SHA256: `06e36af03b6fad9b96ae337550386af6176fc5c3947540b954efcaa4ebda6512`.
- Source provenance: `public/media/astra-hero.provenance.json`. Actual workflow stages begin at 0, 2.55 and 6.99 seconds. `src/data/hero-showcase.json` feeds those same timings into the frame.
- WebM was not added: one sub-megabyte H.264 file plus posters provides broad compatibility without another transfer/storage format. Unsupported codecs fall back safely.
- Production JavaScript gzip budget changed from **309,202 → 170,427 bytes (−44.9%)**, calculated consistently across the old/new requested chunks. Eligible desktop visitors also download the deferred video. This is not a Lighthouse/Core Web Vitals score or a claim that video adds zero bandwidth.

## Files changed

| File(s) | Purpose |
| --- | --- |
| `src/components/HeroShowcase.tsx` | Reusable frame, playback/policy lifecycle, fallbacks, links, transcript and labels |
| `src/hero-showcase.css` | Scoped cinematic layout, controls, browser chrome and responsive/reduced-motion styling |
| `src/pages/Home.tsx` | Integrate the showcase; replace initial WebGL globe with decorative inline vector; retain existing copy/CTAs |
| `src/data/hero-showcase.json` | Recorded duration and synchronized workflow timing |
| `public/media/astra-hero.mp4`, `astra-hero.provenance.json` | Compressed real recording and source/safety provenance |
| `public/images/astra-hero-{poster,mobile}.webp` | Real desktop/mobile static fallbacks |
| `scripts/hero/{serve-astra.py,capture.mjs}` | Capture-only local harness, pinned-source validation, real browser interactions and offline encoding |
| `tests/hero.spec.ts`, `playwright.config.ts` | Policy/playback/fallback/keyboard/accessibility regressions; remove obsolete forced WebGL test flags |
| `vercel.json`, `.gitignore` | Serve media as files; exclude raw capture intermediates |
| `README.md`, this document, `QA-HERO-2026-10-22.{md,json}` | Updated maintenance, provenance and verification evidence |

The original `ThreatGlobe.tsx` and dependency remain available as historical/reusable source but are **not imported or emitted** in the new production hero bundle. Package manifests/lockfile are unchanged. Capture tooling, Flask, FFmpeg and Remotion are not production dependencies.

## Reproduce / maintain

Normal development and validation:

```bash
npm ci
npx playwright install --with-deps chromium
npm run dev
npm run check
npm test
node scripts/make-standalone.mjs /path/to/Jefrine-Correya-Portfolio.html
```

Regenerate the actual demo only when intentionally replacing the reviewed media. These tools run locally/offline, not inside the portfolio bundle:

```bash
# Install FFmpeg and Python 3 using your operating system's package manager.
python -m venv /path/to/capture-venv
# Activate that environment, then:
pip install flask flask-socketio gevent
export ASTRA_SOURCE="$HOME/.cache/hero-projects/astra"
git clone https://github.com/jeff-1217/ASTRA-Monitor.git "$ASTRA_SOURCE"
git -C "$ASTRA_SOURCE" checkout ffa45993badc72b9683beb6e2c8a79fe00a3248d

# Terminal A, from the portfolio repository. Stop this server after capture.
python scripts/hero/serve-astra.py
# Terminal B, same ASTRA_SOURCE environment, from the portfolio repository:
node scripts/hero/capture.mjs
npm run check
npm test
```

The script refuses a different/modified tracked ASTRA source. It records the real UI, derives timeline labels from the actual actions, normalizes frame rates, encodes, and writes both posters/provenance/timing. Always inspect the output before publishing: recording timing and UI font rendering depend on the capture environment. `.cache/hero-capture/` is ignored; do not ship raw captures, source-project dependencies, credential files or local logs.

For a different project, supply another `ShowcaseProject` with actual media and real links, accurate `posterPhase`/workflow timing, and truthful disclosure/transcript. Do not reuse this recording's labels or imply its demo fixtures are live results.

## Verification

`npm run check` passed. Full suite: **70 passed / 4 intentional skips / 0 failed / 0 flaky**, 110.85 seconds, zero retries. Coverage includes real playback/looping, keyboard controls, explicit pause, offscreen/visibility events, reduced motion, Save-Data/slow connections, preference changes, rejected autoplay, deliberately failed media/posters, project links, responsive widths, automated accessibility and the previous contact/documents/navigation/case-study suite. See `QA-HERO-2026-10-22.md` and `.json` for details, exact asset hashes and limitations.

Actual desktop/tablet/phone renderings and the movie's start, modal and final table were inspected. Standalone check: zero HTTP requests, zero runtime errors, embedded poster and working ASTRA case navigation. Production audit reported zero known dependency advisories; not a security guarantee.

### Honest limits and remaining manual checks

- This is an authentic recording of a **simulation's existing sample UI**, not live SOC telemetry or independent verification of detection/response/AI capabilities.
- The project preview opens the real portfolio case study and its source. A public live ASTRA backend is not claimed or separately deployed.
- Chromium desktop/touch configurations were tested; physical iOS Safari/Android, OS low-power mode and manual screen-reader testing remain recommended. Autoplay is never guaranteed; the fallback is intentional.
- Visibility behavior is tested through deterministic visibility events. Real-device LCP/INP/CLS and field bandwidth are not measured, and no fabricated performance scores are supplied.
- Direct website email delivery and preview-first originals are preserved. No additional real email was sent for this release; the previous owner-confirmed receipt remains the delivery proof.
- Dedicated local branch `feat/cinematic-project-hero`; original main, original website, DNS, other projects and remote Git history are unchanged. No force push, merge or remote PR is claimed.


## Published review release

- Live review: **https://jefrine-correya-portfolio.vercel.app**.
- Vercel deployment: `dpl_HGmYNkYxjyAxnFiU11Fae2fzgJH7`, **Ready / production**, in the existing approved `jefftest / jefrine-correya-portfolio` project. Immutable deployment hostname: `jefrine-correya-portfolio-5d9lvvop4-jefftest.vercel.app` (the normal public alias above is the review entry point).
- Implementation commit: `41f3bc254668e171daedff78b6249d237198bf29`, on `feat/cinematic-project-hero`. The final follow-up commit records verification/hand-off only.
- Connected deployment restored the SHA256-verified 52-file production build. Artifact: `08ee560384d65d8397f2d8360b23ad4b971ed2cbcffa09310ef83ba9ff78e74b.tar.gz`, **4,405,567 bytes**. A durable copy is retained at `/.well-known/portfolio-builds/` on the same Vercel site for reproducible redeploys; the deployed site does not depend on this workspace or a running transfer tunnel.
- All **52 public asset hashes** match the reviewed build; all **25 sitemap routes** passed. MP4 responds as `video/mp4` and supports **HTTP 206 byte ranges** (`bytes 0-1023/706686`). Noindex/nosniff and existing PDF download behavior are preserved.
- The **complete suite was also run against the public deployment**: **70 passed / 4 intentional skips / 0 failed / 0 flaky**, **99.91 seconds**, zero retries. It passed after temporary capture/transfer servers and tunnel were stopped. Local validation remains independently recorded at 110.85 seconds.
- Updated standalone HTML, complete source/review ZIP and Git bundle are supplied. The standalone uses the embedded poster deliberately; the separate MP4/live site provide motion.
- No changes to the original `jeffsec.in`, DNS, GitHub main, remote branches, unrelated projects, email-provider setup or supplied PDFs. No remote push, PR or merge.
