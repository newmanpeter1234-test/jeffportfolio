# Liquid-glass footage edit

## Scope and source

This is a **footage-only edit**, not a replacement 3D scene. The owner selected the existing full eight-project film, then requested **1080p / 60 fps** and a larger, minimal autoplay hero.

Source: `public/media/cybersecurity-showreel.mp4`, 41 s, 1280×720, 30 fps. SHA256: `d748a3145926c4e4f2586c0a6704fa6e8c450238be06ee15bd023c1545a45132`. The source is preserved unchanged.

No Three.js scene, original camera-rig data, original project textures, other videos, image-generation service or replacement environment is used by this edit. Tracking, clean-plate inference, material masks and timing are derived from the MP4 itself. The earlier 3D-generation source remains available as history but is not invoked.

## Editorial treatment

- Retain the original continuous dashboard journey and original eight-project order.
- Trim the introductory/closing name sequences and use the continuous source interval approximately 4.27–33.83 s.
- Remove the film's corner name/logo/heading/footer overlays, lower-left chapter names and explanatory captions, chrome/source-capture lettering, decorative chapter digits and non-UI note-card text. Do not replace these with words or logos. Native dashboard titles, controls, data and the real SPL query remain part of the interfaces.
- Preserve the existing panels and interface layers. Empty editorial-label surfaces are repaired/frosted, rather than deleting their entire panel shapes.
- Track the existing planar displays and layers in the footage with OpenCV optical flow and robust homographies. Homographies position **material/repair masks only**; they do not move, rescale or rerender the underlying dashboard content or camera.
- Apply restrained neutral transmission/scattering, soft rounded-edge highlights, low-frequency backdrop blur/color inferred from the same frame, subtle border refraction of that inferred plate and gentle orientation-responsive reflections. Avoid global blur, neon/bloom, new objects, a different environment or a different camera path.
- Use a smooth motion-sensitive timing map: faster original camera travel and less time on slow holds, not a new camera animation.
- Create an **18-second cyclic edit** using a matched dominant-display framing and a 0.6-second tail/head dissolve. This is needed because the original master camera tour is not itself a closed loop; no invented return-camera path is generated.
- Interpolate motion at source resolution, upscale with Lanczos, and apply only mild output sharpening. Export 1920×1080 / 60 fps / H.264 / yuv420p / BT.709 / fast-start / no audio.

## Important quality distinction

The original is **720p/30 fps**. The requested deliverable is a **1080p/60 fps upscaled, motion-interpolated export**, not a claim of native higher-resolution capture or newly recovered fine interface detail. Opaque footage does not contain the exact hidden background behind its screens. The frosted/translucent appearance uses local footage-derived inference within those surfaces; it is not a physically ray-traced reconstruction or a newly designed background. Text repairs similarly reconstruct only affected regions from nearby footage pixels. The existing camera, scene order, perspective, framing and background outside the localized editing masks remain the source footage.

## Website changes

- The homepage player is larger and stands alone.
- Remove the visible kicker/edition, ASTRA/Wazuh/PassChecker tabs, `Security, in perspective` heading, full-film CTA and visible explanatory caption below the hero video.
- Remove the clickable full-film overlay from the footage.
- Use one icon-only corner control: an approximately 28 px glass circle / 11 px glyph inside a 44 px keyboard/touch target. No visible duration or Play/Pause words.
- Enable muted inline automatic playback on normal desktop **and mobile** visits when in view. Continue honoring reduced motion, global motion-off, Save-Data/slow reported connections and browser autoplay restrictions. Explicit playback remains available via the same small control.
- Preserve user pause, offscreen/hidden pause, media-source release when preferences change, static fallback, retry and screen-reader-only scope description.
- Preserve the owner's site header/identity outside the video, Contact/Send mail, documents, facts, cursor, case studies and original full-film archive at `/showreel`. The old film is no longer linked from the clean hero.

## Reusable processing code

- `scripts/footage-glass/edit.json`: immutable input hash, source trim, output specs, manually annotated video-plane anchors.
- `track.py`: bidirectional footage-based optical-flow/RANSAC tracking. A small grayscale working set avoids storing full-resolution frame directories.
- `composite.py`: localized text repairs and tracked image-based glass treatment; no scene or camera rendering.
- `polish.py`: final low-opacity numeral/halo repair, fitted only from nearby original-footage pixels.
- `finish.py`: source-caption stencils, original-footage background restoration and localized fading-layer edge repair; avoids retaining tracking wedges or partial labels at transitions.
- `export.py`: streaming native-resolution composite, footage-motion-derived monotone cubic retiming, optical-flow frame interpolation, cyclic dissolve and 1080p60 encoding. `--encode-only` resumes the second stage from the verified local composite after an encoder/configuration interruption.
- `src/data/liquid-glass.json`, `HeroShowcase.tsx`, `liquid-glass.css`: lightweight ordinary-video website integration. No new production JavaScript library or live graphics runtime.

```bash
# Existing Node dependencies / application
npm ci
npm run dev

# Optional local footage processing: Python, NumPy, OpenCV and FFmpeg
npm run glass:track
npm run glass:export
# Resume encoding only when the local composite is already valid:
python scripts/footage-glass/export.py --encode-only

npm run check
npm test
```

Render and test sequentially on memory-constrained machines. The target is the owner's 8 GB M2; physical M2/Safari testing is not claimed. The sandbox has a smaller memory budget, so browser tests are not run concurrently with optical-flow encoding.

The finishing stages repair the original footage rather than trusting a faded/occluded plane tracker to introduce a new glass polygon. The original background is restored around featured panes from the source frames, with a final localized numeral clean-plate pass.

The native composite is checkpointed under ignored `.cache` so encoding corrections do not repeat the slow footage pass. A normal `glass:export` also runs the final overlay/edge pass.

Final file specifications, encoded-video review, playback/regression results and publication evidence are recorded below after verification.


## Verified delivery

- `public/media/cybersecurity-liquid-glass-loop.mp4`: **18.00 seconds**, **1920×1080**, **60/1 fps**, **1,080 decoded frames**, H.264 High / level 4.2 / yuv420p / BT.709 / fast-start / no audio.
- Final file: **10,430,734 bytes** (about 10.43 MB). SHA256 `4e5302fbd9956cafebb779d8f01c987bd9b122e5ccf3a8d84cb2cd6d5a5d8d85`.
- Zero blank frames. Encoded boundary mean absolute RGB difference: **1.727/255 at 160×90 QC size**. This is a continuity diagnostic, not a byte-identical/pixel-perfect reconstruction claim.
- All eight project interfaces remain in the original order. Actual encoded samples, transitions and source-frame masks were inspected; leftover caption fragments, opacity-fading layer wedges and numeral halos prompted additional localized finishing passes.
- Original master SHA256 remains unchanged.
- Local production build/content validation passed; full suite **86 passed / 2 intentional skips / 0 failures or flaky**, 140.70 seconds. The previous two mobile autoplay skips are removed because mobile now participates in eligible automatic playback.
- Tests cover actual 18-second 1080p playback, desktop/touch autoplay, reduced motion/data preferences, loop/offscreen/visibility, persistent pause, tiny control size/focus, video/poster failures and retry, no hero labels/links, existing contact/documents, 19 cases and the preserved archival film.
- One browser test attempt was stopped while optical-flow encoding exhausted the smaller sandbox's memory. Rendering and tests were subsequently serialized; the completed full run above passed. No M2 hardware timing or native-1080p claim is made.
- The homepage player now has no visible chapter navigation, title/caption/full-film CTA or source badge. The 28 px visual corner control retains a 44 px accessible target. Muted autoplay is eligible on desktop and mobile, with accessibility/data/browser-policy exceptions.

The original site/domain/DNS/main branch, other projects, contact provider and original PDFs are not modified. Local feature branch only; no remote push/merge/PR is implied. Generated duplicate old build archives were moved to excluded cache after SHA verification; authored source/history/documents remain intact.


## Published preview and final handoff

- Homepage: **https://jefrine-correya-portfolio.vercel.app**. Direct edited MP4: `/media/cybersecurity-liquid-glass-loop.mp4`.
- Existing approved `jefftest / jefrine-correya-portfolio` project only. Deployment `dpl_4QdXUX9N4sLd9iDscBDqnbgp1CVw` is **Ready / production**; implementation commit `bccd8badfe8ef08ff1bae5771501abdd3b50a2d9` on `feat/liquid-glass-footage-edit`. No new project/domain/DNS or main-branch deployment.
- **62 asset hashes / 26 sitemap routes** verified publicly. Edited MP4 MIME is `video/mp4`; HTTP 206 Range responds `bytes 0-1023/10430734`. Original master also matches its original hash/range. Existing noindex/security/PDF behavior retained.
- Full suite against the published site: **86 passed / 2 intentional skips / 0 failures or flaky**, **98.30 seconds**, zero retries. This independently validates the final media asset after local full-suite and final-player checks. It is not 172 different tests.
- Verified static build artifact: `5282ebc05c50f10e8a1d8de2a0531c5f23cc86907bf6e0c8fef5adcd7e4f2be1`, 19,500,064 bytes. Durable SHA-verified copy retained under `/.well-known/portfolio-builds/` on the same site; runtime does not depend on the transfer tunnel/workspace. Temporary transfer processes were stopped before public UI tests.
- Source ZIP is refreshed without duplicating the new large MP4 or standalone HTML; those are delivered separately. Place the downloaded edited MP4 at `public/media/cybersecurity-liquid-glass-loop.mp4` before a source-only build, or regenerate it with the documented processing commands. The original 41-second source is included/preserved.
- The previously supplied Git bundle remains the historical eight-project-film handoff, not the current glass-edit branch. Current authored source/history remain intact in this repository and source ZIP; no remote push/PR/merge is claimed. Main remains `809388399e17c9e949f14ef201ece51701ec5816`.
