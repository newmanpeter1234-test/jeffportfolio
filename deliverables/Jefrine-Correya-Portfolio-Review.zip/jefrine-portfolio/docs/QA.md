# Executed validation

Executed locally on 14 October 2026, using Chromium / Playwright. Machine-readable summary: `docs/QA-results.json`.

## Results

- `npm run build`: **passed**. TypeScript strict checking and the Vite production build completed. WebGL and motion dependencies are separate chunks; the largest emitted JS chunk is approximately 480 kB before gzip.
- `npm run test:content`: **passed**. 19 case studies, 26 public repositories, two earned credentials, one pursuing qualification, all 20 original self-rated skills, explicit project evidence / boundaries, available local images / fonts, and the original résumé SHA-256 were asserted.
- `npm test`: **30 passed, 2 intentionally skipped, 0 failed** across desktop and mobile. The skips are the mobile-menu test on desktop and the duplicate viewport sweep on mobile.
- Automated axe checks for WCAG 2 A/AA and 2.1 AA tags: **no violations** on Overview, Projects, ASTRA case study, Journey, Credentials, Contact, and Sources, in both desktop and mobile tests. This is not a complete manual accessibility certification.
- Horizontal-overflow sweep: **passed** at 320, 390, 768, 1024, and 1440 px on six primary / case-study routes.
- Production preview smoke test: **passed** on seven routes, with **zero page errors and zero failed HTTP responses**. The normal-motion investigation sequence also completed in the built application.
- Standalone HTML: **passed** inside an `allow-scripts` iframe with an opaque origin and **all network requests blocked**. Navigation, 19 project cards, two Wazuh search results, case-study navigation, and embedded original imagery worked with **zero page errors**.
- `npm audit --omit=dev`: **0 known vulnerabilities reported** at validation time. This is a dependency-advisory check, not an application penetration test.

## Functional coverage

Real identity and CTAs; search and category filters; rapid filter/typing updates; empty-state reset; all 19 case-study titles/evidence/scope; 26-repository index; keyboard quick access and Escape close; mobile navigation; local investigation scenarios and reset; skills tabs / original proficiency levels; confirmed experience and credential status; actual PDF download; required-field validation and email-draft preparation; reduced-motion defaults and manual override; useful 404 recovery paths; responsive layout.

## Honest remaining limitations

- A remote PR could not be opened: authenticated GitHub access was unavailable. The feature branch, source package, review bundle, and PR body are prepared locally.
- No site was deployed, and the live domain was not modified.
- Hosted project demos are preserved external links, not uptime guarantees.
- The contact form opens the visitor's email application; no backend email delivery service is configured and no send is faked.
- Clipboard / email app / download behaviour can be restricted by a sandboxed viewer; the downloaded file or live local preview has the normal browser experience.
- The résumé remains unmodified and lists Bengaluru, while Kochi is the user-confirmed website location.
- No Lighthouse score, formal security audit, award, credential verification ID, or production detection result is claimed.
