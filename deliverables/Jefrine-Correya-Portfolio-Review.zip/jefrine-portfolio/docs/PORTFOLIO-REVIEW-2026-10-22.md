# Jefrine Correya — portfolio update and improvement review
**Reviewed: 22 October 2026**
Scope: the redesigned portfolio, not the original `jeffsec.in` deployment.

## Latest multi-project 3D showreel

The current release replaces the single-project hero recording with a **41-second, eight-project Three.js cinematic camera journey** and a separately choreographed **10.8-second closed loop**. It uses real interface captures and original report evidence, not synthetic dashboards. All 1,554 encoded frames decode; the local full suite passes **84 checks with 4 intentional skips and zero failures/flaky**. Master: 3.63 MB; loop: 0.94 MB. Playback remains preference-aware and the full film loads on demand at `/showreel`. Full source, commands and honest limits: `SPATIAL-SHOWREEL.md`. The sections below record earlier completed releases and longer-term recommendations.

## Latest cinematic hero follow-up

The hero now features an authentic, clearly labelled **10.8-second ASTRA sample-interface recording**, an elegant browser frame, real project/source links and a lightweight inline globe accent instead of initial WebGL. Identity, contact delivery and preview-first PDFs remain intact. Release validation: **70 passed / 4 intentional skips / 0 failures or flaky tests**, both locally and in a separate full run against the public Vercel deployment. All 52 public asset hashes and 25 sitemap routes also passed. The recording is **not live threat telemetry**. Mobile, reduced-motion and low-data visitors get the real poster by default. See `HERO-UPGRADE.md` and `QA-HERO-2026-10-22.md` for decisions, reproduction, exact budgets and limitations.

## What has been improved now

- Replaced the résumé with the exact supplied Qatar résumé, including the legacy résumé URL.
- Added the original CICSA, EC-Council CSA, and Wahy Lab Solutions experience PDFs.
- Replaced automatic-download entry points with **View my résumé**, **View my certificate**, and **View my experience** buttons.
- Added a consistent **Document Room**: four-document switching, whole-page fit, zoom, readable text, keyboard navigation, Escape-to-close, restored focus, and optional **Download PDF** inside the viewer only.
- Generated visual previews from the actual PDFs rather than relying on an embedded browser PDF plug-in. This avoids the forced-download behavior that can occur on mobile browsers. Original downloadable files are unchanged.
- Replaced decorative credential artwork with thumbnails of the supplied certificates. Corrected issue dates to **27 July 2025 (CSA)** and **11 July 2025 (CICSA)**. The uploaded certificate is CICSA, not “CICAC.” Displaying a certificate is not independent issuer verification.
- Updated the current location to **Doha, Qatar**, including the hero, biography, contact area, footer, mobile menu, globe origin/coordinates, page descriptions, and structured data. The live clock now uses **Asia/Qatar / AST / UTC +03:00**. Historical work/training/education locations remain accurate.
- Added a screenshot-inspired, curved triangular **lime arrow cursor** for desktop. It is a native SVG cursor, not a lagging JavaScript follower. Text inputs retain the text cursor, touch devices retain normal touch behavior, and forced-color mode has native fallbacks.
- Aligned the Wahy Lab Solutions role/responsibility summary with the supplied résumé and experience letter, without adding unsupported metrics or employment.

## Earlier document-release validation

- Production build and content-integrity checks passed.
- **38 Playwright tests passed; 2 intentional platform-specific skips; 0 failures and 0 flaky tests.**
- Eight additional targeted tests also passed on the public Vercel deployment. All 50 reviewed assets matched the build and all 25 sitemap routes responded correctly.
- All four documents were previewed on desktop and mobile without opening a download automatically. Explicit downloads matched the uploaded PDFs by SHA256.
- Keyboard focus containment/recovery, zoom, text mode, and modal/quick-search interaction passed.
- Automated WCAG A/AA checks passed on seven principal routes and all four document previews in desktop and mobile configurations. This is not a full manual screen-reader/accessibility certification.
- Page layout was checked at 320, 390, 768, 1024, and 1440 px. Document overlays were additionally checked at narrow widths.
- All four document previews also worked inside a no-network, opaque-origin sandboxed iframe. Browser sandbox permissions can still restrict optional downloads.
- The production-dependency audit reported **0 known vulnerabilities** at the time of this review; this is not a guarantee against all security issues.

## Highest-value next improvements

These are recommendations, not changes silently made to your career details or original PDFs.

### 1. Make your target role obvious in the first few seconds — high priority
Your new résumé uses **SOC & Security Platform Engineer**, whereas the website hero remains the broader SOC/cybersecurity introduction. Consider a concise role line such as **SOC Analyst / Security Platform Engineer**, followed by evidence-backed specialties: SIEM, SOAR automation, and detection engineering. Keep the actual job title in the experience timeline separate from the role you are targeting.

**Also add your ongoing MCA at Sikkim Manipal University to the Journey page** if you want that education publicly displayed. It appears in the new résumé but is not yet a separate website timeline entry.

### 2. Resolve the remaining résumé/status details — high priority
- Your new PDF visibly contains literal Markdown `**` around part of the summary. Clean those up in the résumé source on a future revision; the file supplied for this task was intentionally not rewritten.
- Its header says `(Qatar / Dubai)`, while your confirmed current base is Doha. Separate **current location** from **target job markets** so recruiters do not need to infer your location.
- Confirm whether CompTIA Security+ is still in progress. It appeared in the earlier résumé but is absent from the new one. The site keeps it separate as a learning goal, never an earned certificate.
- Add availability, a Qatar contact number, work authorization, or relocation preferences only if accurate and you choose to publish them. None should be guessed.

### 3. Lead with three or four proof-rich case studies — high priority
You have 19 case studies and a 26-repository research snapshot. Prioritize the strongest SOC/platform work instead of making every small lab equally prominent. For each flagship case, show the problem, architecture, your contribution, an actual redacted artifact, limitations, and reproducible setup steps.

Useful artifacts include an SPL query, a Wazuh detection rule, a triage report, an n8n workflow, or a Docker/SOAR architecture diagram. The **Docker / ELK / n8n / TheHive lab in your new résumé** is a strong future case study once you provide a repository or shareable evidence. Keep credentials, API keys, real client logs, and sensitive incident data out of public demos. Add performance metrics only when genuinely measured.

### 4. Choose the primary domain and search-indexing plan — high priority when launching
The redesigned Vercel copy is deliberately `noindex`, and canonical metadata still points at the original `www.jeffsec.in` domain. That is appropriate for a separate review copy; it is not a final SEO launch configuration.

When you decide this redesign should become your primary portfolio, select the domain, update canonical/social-preview/sitemap URLs consistently, and enable indexing. Do not point two indexable copies at conflicting identities. The original site and DNS have not been changed by this update.

### 5. Make recruiter contact reliable — completed in the follow-up
The email-draft-only form has now been replaced with direct FormSubmit delivery, a **Send mail** button, validation, a honeypot, pending/duplicate-submit protection, and honest success/error handling. Fields are kept on errors; direct email and LinkedIn remain fallbacks. The owner confirmed the test email arrived after activation. Form data is processed by FormSubmit; do not submit sensitive security data. This is a delivery-service integration, not a claim that the static website itself runs an email server.

### 6. Add independent credential verification where available — medium priority
Scans improve transparency, but an issuer-hosted verification link is stronger than a PDF alone. Add official verification URLs only when available and checked; retain the supplied QR codes and certificate details without inventing a verification claim. Do not expose additional identifiers beyond what you are comfortable making public.

### 7. Replace subjective proficiency labels with evidence — medium priority
The toolkit preserves your earlier self-reported levels. For recruiter credibility, consider linking skills to concrete proof: “Splunk → SPL investigation,” “Wazuh → custom rule,” “Python → enrichment pipeline.” Evidence is more persuasive than a long list of “Advanced” ratings, particularly when distinguishing training, lab work, and paid experience.

### 8. Measure real-device performance — remaining follow-up
The cinematic hero release removes the initial Three.js/WebGL runtime and uses poster-first policies plus a deferred, sub-megabyte real recording. Consistently calculated JavaScript gzip bytes fell by 44.9%; this is not a field-performance score. Measure LCP, INP and CLS on physical devices and slower networks before making broader speed claims. The preview-first documents remain on demand and add no PDF-rendering worker to the initial page.

### 9. Make updates reproducible and safe — medium priority
Connect the source-control workflow when you are ready: feature-branch previews, build/content checks, document-preview tests, and explicit production promotion. Do not auto-merge or deploy `main` without your chosen review process. Git-based auto-deployment is not currently connected.

A repeatable document update is already supported by `scripts/prepare-documents.py`: replace the original public PDFs, regenerate page previews/metadata, review the expected hashes, and rerun checks. A protected document-management interface is worth considering only if you will update documents frequently; a public upload endpoint would be unnecessary risk.

## Boundaries

Original PDFs remain exactly as supplied. No employment, certification, visa status, metrics, issuer verification, or new project results were invented. Current-base updates do not rewrite the historical locations of your work and education. The existing domain and GitHub `main` are outside the changes made here.
