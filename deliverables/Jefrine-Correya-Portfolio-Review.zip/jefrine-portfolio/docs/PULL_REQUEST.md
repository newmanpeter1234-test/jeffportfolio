## Summary

Reimagines Jefrine Correya’s portfolio as an editorial, cybersecurity-focused security dossier. This is a feature-branch-only redesign for review; do not merge or deploy without the owner's explicit approval.

## Experience

- Interactive Three.js point-cloud globe with drag / arrow-key / button controls and WebGL fallback.
- GSAP entrance and scroll reveals, fine-pointer cursor feedback, animated SVG/CSS project artwork, and interactive skills tabs.
- Local SOC investigation experience with SSH, URL, and exposed-service scenarios. Clearly labelled simulation; no live scanning or API calls.
- Searchable / filterable project archive, 19 evidence-linked case studies, and all 26 public repositories indexed.
- Dedicated Journey, Credentials, Contact, and Content Sources pages.
- Command / Control K quick access, accessible modal focus management, mobile navigation, reduced-motion support, and manual animation control.
- Preview-first résumé, original certificate and experience-letter viewing, optional downloads inside the Document Room, and an updated legacy résumé URL. Contact form submits directly through FormSubmit, requires owner activation, and never reports success without a positive service response.

## Content integrity

Research follows the original live site, public repositories, and the updated résumé and three certificates supplied on 22 October 2026. Current location is Doha, Qatar. The experience letter confirms Wahy Lab Solutions, 1 September 2025–29 May 2026. Certificate issue dates follow the actual PDFs: EC-Council CSA, 27 July 2025; CICSA, 11 July 2025. Original uploaded PDFs remain unchanged.

CSA v1 and CICSA are earned. Security+ is pursuing. All 20 original self-rated skills are retained. No fabricated employers, dates, clients, certificate IDs, official badges, detection rates, or incident metrics are added. Lab / prototype scope and the IOC README's self-reported estimate are explicit. See `docs/CONTENT-SOURCES.md`.

## Engineering

React 19, TypeScript, Vite, Three.js, GSAP, and Lucide icons. Self-hosted subsetted WOFF2 fonts, local assets, lazy-loaded WebGL, capped renderer pixel ratio, visibility-based pause, and resource disposal. Route metadata, JSON-LD, sitemap, static-host SPA rewrites, and a no-JavaScript résumé/contact fallback are included. No deployment workflow or secret is introduced.

## Validation

- TypeScript / production build: `npm run build`
- Content assertions: `npm run test:content`
- Desktop and mobile functional / automated WCAG A-AA checks: `npm test`
- Five-width, six-route horizontal-overflow sweep.
- Standalone no-network sandbox preview and production-route smoke checks.

See `docs/QA.md` for the final executed checks. Automated checks do not constitute a full manual accessibility certification.

## Safety

This PR body is prepared locally. GitHub authentication was unavailable in the build environment, so the remote PR was **not** created automatically. No main-branch commit, push, or merge was performed. The isolated Vercel review copy is manually deployed; the original site/domain are untouched.

## Follow-up QA — 22 October 2026

See `docs/QA-2026-10-22.md`: 38 passed, 2 intentional skips, no failures/flaky tests; preview-first downloads, original file hashes, accessible modal, Doha/timezone consistency, native SVG cursor, and offline document previews covered. The separately hosted Vercel review copy is the deployment target; the original domain and main branch are unchanged.
