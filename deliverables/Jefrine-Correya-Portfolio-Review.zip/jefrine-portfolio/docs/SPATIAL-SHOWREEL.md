# Cybersecurity, in perspective — cinematic showreel

22 October 2026. Dedicated branch `feat/spatial-cybersecurity-showreel`, based on clean `93b8868`. Existing contact/documents/hero implementation audited; original main remains untouched.

## Audit before implementation

The repository is React 19 / TypeScript / Vite with React Router, GSAP and an existing Three.js dependency. The current hero plays an authentic single-project ASTRA capture in a browser frame. Its limited camera motion is unsuitable for the requested multi-project film; the composition and motion system will be replaced, not merely zoomed again.

Inspected: application routes and all 19 project definitions, all public image/media assets, current player/lifecycle and responsive styles, case-study/evidence links, capture scripts, package/lockfile, Vite/deployment configuration, existing functional/accessibility tests, repository inventories and original implementations/reports. The GitHub connector is unsupported, so explicitly named public source files were fetched at pinned public Git commits. No private repository, credential or environment file was opened.

### Project selection

| Project | Authentic visual evidence | Scene direction |
| --- | --- | --- |
| ASTRA Monitor | Previously verified real sample table/detail capture; original implemented modal | Oblique forward approach, leftward track, modal separated in depth |
| SOC Threat Detection Assistant | Actual linked Streamlit implementation, empty log-entry interface; source excerpts | Backward pull and ascending reveal |
| Splunk SOC Lab | Actual Splunk screens embedded in the original SOC report; published SPL source | Controlled three-quarter orbit around evidence layers |
| URL Phishing Detector | Original Flask template, untouched empty form; no external lookup | Right-to-left edge reveal into a front-facing read |
| Wazuh SIEM Lab | Original report's actual threat-hunting/event-table captures | Low-to-high vertical reveal and report-detail parallax |
| Web Vulnerability Scanner | Original scan-configuration form, no scan submitted | Descending forward track through layered configuration |
| PassChecker | Working original client-side HTML/JS; clearly synthetic example input | Diagonal push/pull with genuine local feedback |
| Wireshark Network Traffic Analysis | Published real packet-list capture, privacy redactions | Lateral boom and pullback toward the complete gallery |

The other 11 cases were considered: SLMS and Netflix are frontend/prototype work rather than the strongest cybersecurity selection; ML Threat Monitor lacks an independently linked implementation; IOC Automation Pipeline is primarily documented architecture without an exported runnable interface; phishing-email, Nessus, portscan, UFW, password-analysis, browser-extension and VPN projects are valid evidence/report exercises but overlap the chosen capabilities or offer less distinctive, verified UI evidence for this film.

Important audit findings:
- Splunk cover/dashboard mockups and the stylized Wazuh repository cover are **not used as genuine UI**. Original report captures are used instead.
- One SOC repository JPG is actually an XML error document; it is excluded. The linked Streamlit source provides a real interface instead.
- ASTRA uses existing simulated fixtures, not live telemetry. Unimplemented Block/Escalate buttons are never presented as successful actions; unverified accuracy/confidence is omitted.
- The Streamlit tip's assertion about a known malicious IP is omitted from the capture. No API key, lookup, threat verdict, generated incident or analyst report is fabricated.
- The URL tool's API-failure behavior cannot justify a safe verdict. Only its original input interface is shown; no URL is submitted.
- Scanner controls are shown without running Nmap or scanning any host. Marketing/demo placeholders are not shown as real findings.
- Password feedback comes from the original local heuristic on an explicitly synthetic example, not a real password or a resistance-to-attack benchmark.
- Wireshark uses published historical evidence, not a fresh packet capture. Address/identifying payload details are omitted/redacted.

## Implementation plan

1. Prepare clean, source-traceable captures and report crops. Preserve original branding/content, omit secrets/private data, and record source hashes, pins and redactions.
2. Create a small offline Three.js studio with reusable panels, lighting/environment, typography, deterministic camera paths and scene configuration. Use actual PerspectiveCamera movement and true world-space depth; no screenshot-scale-only choreography.
3. Compose a 41-second master: identity reveal, eight recognisable scenes, a connected spatial tour, and a gallery/signature pullback. Build a separately choreographed closed 10.8-second hero journey from the same components, not a random trim.
4. Render frames sequentially through Playwright into an FFmpeg pipe: no thousands of full-resolution frame files, unbounded parallel browsers, large particle systems, post-processing stack, R3F or Remotion dependency. Reuse existing Three.js; no new production libraries.
5. Inspect actual rendered frames and the complete encoded videos. Verify all eight projects, distinct depth/angle/motion, readable framing, loop continuity and metadata. Revise if a shot is static, cropped or jumps.
6. Integrate the optimized hero asset/static posters into the existing portfolio with the existing preference/visibility policy. Offer an accessible full-film viewer and real project links without autoplay audio. Regress the existing site and build/tests.

The completed implementation, export commands, measured verification and remaining limitations follow.

## Completed implementation

The delivered master is **41 seconds**, with an opening, eight four-second project chapters and a gallery/signature pullback. The separate **10.8-second hero** has a compact three-station layout (ASTRA, Wazuh, PassChecker) and a closed camera path. It is not a crop or random trim of the master.

This is actual Three.js spatial composition: `PerspectiveCamera` position/target change in X/Y/Z; project displays occupy different world positions, depths and orientations; foreground source/detail cards sit in front of their original screens; a continuous camera visits the displays. Intra-station camera moves use eased spherical interpolation rather than cutting a chord through a panel. Inter-station movement is a genuine camera flight. No screenshot-scale animation substitutes for the camera.

A restrained dark studio, reflective beveled frames, 144 seeded soft particles, thin decorative network geometry and local portfolio typography provide the setting. Interface textures remain authentic. UI layering is editorial motion design—not a claim that the projects themselves implement a 3D interface. Focus lighting/caption fades are not used to replace spatial transitions.

### Delivered files

| File | Specification | Bytes |
| --- | --- | ---: |
| `public/media/cybersecurity-showreel.mp4` | 41 s; 1280×720; 30 fps; H.264 Main; yuv420p; BT.709; fast-start; no audio | 3,633,975 |
| `public/media/cybersecurity-hero-loop.mp4` | 10.8 s; 1280×720; 30 fps; same web-compatible encoding; no audio | 939,012 |
| `public/images/cybersecurity-showreel-poster.webp` | 1280×720; genuine eight-project 3D gallery render | 36,466 |
| `public/images/cybersecurity-showreel-mobile.webp` | 704×396; uncropped, smaller static fallback | 12,726 |
| `public/media/cybersecurity-showreel.en.vtt` | Ten English scene-description caption cues | — |
| `public/media/cybersecurity-showreel.provenance.json` | Public source pins, actual evidence crops/redactions and export integrity | — |

The master is optimized for web delivery, not described as a 4K/Full-HD master. Higher-resolution export is supported by the source commands below but is not claimed as an additional delivered file.

### Reusable source architecture

- `scripts/showreel/scene/config.mjs`: eight real project definitions, project-specific shot signatures, poses, lighting accents and separate hero layout.
- `scene/timeline.mjs`: deterministic timing, quintic easing, local/world transforms, true orbital interpolation and closed hero path.
- `renderer/panel.mjs`: beveled 3D display, contained original UI image, browser chrome, source/detail layer, depth and focus treatment.
- `renderer/environment.mjs`: shared lighting, lightweight reflection environment, seeded points, floor and decorative connections.
- `renderer/typography.mjs`, `hud.mjs`: local-font world-space typography and deterministic final-frame compositing.
- `renderer/main.mjs`, `studio.mjs`: reusable scene assembly and local render studio. These do **not** enter the website build.
- `research-sources.py`, `source-pins.json`, `prepare-capture.py`, `capture-lab.py`, `capture-interfaces.mjs`, `prepare-assets.py`: optional, source-traceable capture preparation, original UI capture and report extraction. Provided textures can be reused without installing/running the original applications.
- `render.mjs`: one browser, one frame in flight, bounded encoder backpressure, atomic final output; no thousands of frame files. JPEG97 composites stream to two-thread FFmpeg/x264.
- `verify-scene-system.mjs`, `verify-media.py`: integrity/framing/camera checks and full encoded-file decoding/QC samples.
- `export-site-data.mjs`: lean website chapter metadata and scene-description VTT, generated from the same scene configuration.

No React Three Fiber, Remotion or new JavaScript dependency was added. Vanilla Three.js already existed and is sufficient here. Existing website GSAP remains unchanged; the offline film uses explicit deterministic camera mathematics. The production package/lockfile dependencies are unchanged; only convenient npm scripts were added.

## Rendering and export commands

### Normal rerender using the provided real textures — recommended on the M2

From the portfolio repository:

```bash
npm ci
npx playwright install chromium
# Install FFmpeg separately; on macOS, for example: brew install ffmpeg

# Terminal A: offline studio (0.0.0.0:5050)
npm run showreel:studio

# Terminal B: render sequentially, not concurrently
npm run showreel:render -- --mode=master --width=1280 --height=720 --fps=30 --crf=25
npm run showreel:hero -- --width=1280 --height=720 --fps=30 --crf=25
node scripts/showreel/export-posters.mjs
node scripts/showreel/export-site-data.mjs
npm run showreel:verify

# Optional encoded-file QC: Python + Pillow
python scripts/showreel/verify-media.py
npm run check
npm test
```

The Mac commands intentionally omit `--software`: allow Chromium to use the M2 graphics path. In the Linux sandbox, `--software` was supplied explicitly for SwiftShader. Actual software-render times were approximately **678 seconds master / 149 seconds hero**; these are **not M2 benchmarks**.

A smaller preview or optional higher-resolution render uses the same deterministic scene system:

```bash
npm run showreel:render -- --mode=master --width=640 --height=360 --fps=12 --crf=27 --output=.cache/showreel/preview.mp4
# Optional, not a separately delivered or benchmarked output:
npm run showreel:render -- --mode=master --width=1920 --height=1080 --fps=30 --crf=22 --output=.cache/showreel/full-hd.mp4
```

### Recapture original interfaces only when intentionally refreshing evidence

This is optional. No backend/API/Flask/Streamlit installation is needed to rerender the supplied texture pack or build the website.

```bash
# Use an isolated Python environment; FFmpeg is also required.
python -m venv .venv
# Activate .venv using your shell's normal command, then:
pip install -r scripts/showreel/capture-requirements.txt
python scripts/showreel/prepare-capture.py

# Terminal A: original-template capture lab; submissions disabled
python scripts/showreel/capture-lab.py
# Terminal B: original linked Streamlit UI, with credentials/dotenv/lookups disabled
streamlit run .cache/showreel/soc-capture.py --server.address=0.0.0.0 --server.port=5053 --server.headless=true --server.enableCORS=false --server.enableXsrfProtection=false --browser.gatherUsageStats=false --theme.base=dark
# Terminal C:
node scripts/showreel/capture-interfaces.mjs
python scripts/showreel/prepare-assets.py
```

Then inspect the captures, rerender, verify and stop both capture servers. Original source files are fetched at the pinned commits. The old verified ASTRA capture/poster remain as inputs to the ASTRA texture extraction. Report crops are extracted from the original PDFs; no synthetic dashboard is substituted. The large Wireshark source is normalized before applying the documented privacy coordinates. Do not show real passwords, credentials, private logs, or unverified threat/API verdicts.

## Website integration

- `HeroShowcase.tsx` retains the tested source-free, preference-aware lifecycle but now presents the multi-project film rather than an ASTRA-only browser recording. The outer fake browser address/chrome is removed; the browser frames live in the actual 3D footage.
- The hero defaults to a real eight-project gallery poster on mobile/coarse pointers, reduced motion, global motion-off, Save-Data and slow reported connections. Explicit play remains available. Visibility/offscreen pause, persistent user pause, blocked autoplay and image/video fallbacks remain tested.
- Hero chapter links open the actual ASTRA, Wazuh and PassChecker case studies. The main preview/full-film CTA opens `/showreel`.
- `/showreel` requests **no video until explicit play**, provides native controls, optional captions, a complete readable transcript, an explicit download, all eight real case/source links and honest media errors/retry. Hidden/offscreen master playback pauses without silently restarting.
- The production build contains **no Three.js/studio scene chunk or running project backends**. Visitors download ordinary H.264 when eligible/requested. No autoplay audio; both files have no audio stream.
- The standalone HTML intentionally stays poster-only and links to the live film; it does not pretend to play/fetch a missing embedded MP4 offline.
- Original branding, professional facts, Doha/time, Contact/Send mail, native 24×30 cursor and preview-first original PDFs remain preserved. The Wazuh cover caption was corrected to distinguish its illustration from the actual report UI used in the film.

## Verification and review

- Production build and source/content checks passed.
- Full desktop/touch-mobile suite: **84 passed, 4 intentional skips, 0 failures or flaky**, **160.31 seconds**, zero retries. Existing contact, documents, 19 cases, 26 repository links, navigation, keyboard and layout coverage remain included. New checks cover the film page, real playback/retry, ten caption cues, transcript, source links and offline behavior.
- Automated WCAG A/AA checks passed, including the new viewer. This is not a comprehensive manual screen-reader certification.
- **All 1,554 encoded frames were decoded**: 1,230 master + 324 hero, zero blank frames and no audio streams. Actual 41.0 / 10.8-second durations, 30 fps, H.264 Main/yuv420p and fast-start atom order verified.
- Actual encoded-video half-second samples were reviewed across the entire film: **82 master + 22 hero samples**, plus featured full-frame exports. All eight projects appear; the orbit/edge, push/pull, horizontal, ascending/descending and gallery transitions are visible and distinguishable.
- Camera framing checks cover the dense timeline: zero featured main-panel crop violations. Cameras actually span X/Y/Z; no screenshot-scale substitution. Separate hero start/end camera positions and targets match exactly.
- The decoded hero last/first seam mean absolute RGB difference is **0.453 / 255** at the 160×90 QC size. This is a continuity diagnostic, not a claim that lossy encoded frames are byte-identical.
- First-pass review caught the large Wireshark-image coordinate mismatch. The source was normalized, both address columns/SNI rows were visually checked, and the **entire master was rerendered**. Wording about recommendation review was also clarified; no human-reviewed result is falsely implied.
- Native master network failure/retry testing caught an error-message race; it was fixed and the actual retry passed.
- Production dependency audit reported zero known advisories at review time; not a security guarantee.

Structured evidence: `QA-SPATIAL-SHOWREEL-2026-10-22.json`, the public provenance JSON, `scripts/showreel/assets/evidence.json`, and source pins. Intermediate frames/raw downloads/first passes stay under ignored `.cache/`, not in commits or production.

### Honest remaining limitations

Physical M2/Safari/Android and manual assistive-technology testing were not available. The design is hardware-conscious, not presented as an M2 benchmark or a field Core Web Vitals score. Original scanned report UI has inherently softer fine text than live frontend captures; the real report/source links remain available for full fidelity. No API-backed verdict, firewall action, live telemetry, client incident volume or production detection accuracy is fabricated or independently verified by this film.

Contact provider state is unchanged. Tests mock delivery responses and are not new inbox-delivery proof; the owner's earlier received-email confirmation remains the real delivery evidence. No additional real email was sent. Original site/DNS/GitHub main and other projects are untouched; no remote push, PR or merge is claimed.


## Published release and handoff

- Live film: **https://jefrine-correya-portfolio.vercel.app/showreel**. Overview/short loop: **https://jefrine-correya-portfolio.vercel.app**.
- Existing approved project: `jefftest / jefrine-correya-portfolio`. Deployment `dpl_DZhP33t7cx5XtAworyqy6PgbSZpY` is **Ready / production**. No new Vercel project or custom domain.
- Implementation commit: `1115b6d877f00f18be4370f8dd07843373bf710c` on `feat/spatial-cybersecurity-showreel`; the follow-up commit records verification only.
- All **58 public asset hashes** match the reviewed build; all **26 sitemap routes** passed. Both MP4s respond as `video/mp4` and support HTTP 206 byte ranges. Scene captions respond as `text/vtt`; security/noindex/PDF behavior is preserved.
- The **complete suite also passed against the public deployment**: **84 passed / 4 intentional skips / 0 failed / 0 flaky**, 115.85 seconds, no retries. This is a second run of the same checks, not 168 distinct tests. Temporary capture/studio/transfer processes had been stopped; the site is independent of the workspace.
- Reviewed static artifact SHA256: `2ddbca440755b12a572a66f61347d3d4c91db707f55a6e0339dba137fe94723b`, 9,022,538 bytes. A durable copy is retained on the same site under `/.well-known/portfolio-builds/`. The connected deployment used a SHA-verified static build; normal source deployments use `npm ci` / `npm run build` and need no capture/render toolchain.
- Refreshed source/review ZIP includes the complete working source, render configuration/textures, both MP4s, posters, captions, documentation and standalone HTML. The complete-history Git bundle is supplied **separately**, rather than duplicated inside the ZIP.
- Standalone opaque-origin check: zero HTTP requests, zero runtime errors, eight case links and the explicit live-film link; no attempt to play a missing offline video.
- Original main remains `809388399e17c9e949f14ef201ece51701ec5816`. Original site/DNS, other projects, remote branches and supplied PDFs unchanged; no push/PR/merge. Only the portfolio development preview remains running.
