from pathlib import Path
from urllib.request import urlopen
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]/'jefrine-portfolio'
FILES={'astra-hero.mp4': '06e36af03b6fad9b96ae337550386af6176fc5c3947540b954efcaa4ebda6512', 'cybersecurity-hero-loop.mp4': 'ebc572cebfecccc5c28446ee1124952f501cb6d0919068152551e1bf2d05f7f7', 'cybersecurity-showreel.mp4': 'd748a3145926c4e4f2586c0a6704fa6e8c450238be06ee15bd023c1545a45132', 'cybersecurity-native-glass-1080p60.mp4': 'd6da76f987e75f9f0cc5edb5e6b1f42646d089664a17c9a7d84b0f891544d503'}
for name,sha in FILES.items():
 p=ROOT/'public/media'/name
 if p.exists()and hashlib.sha256(p.read_bytes()).hexdigest()==sha:continue
 b=urlopen('https://jefrine-correya-portfolio.vercel.app/media/'+name,timeout=120).read()
 assert hashlib.sha256(b).hexdigest()==sha,name+' integrity mismatch'
 p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix('.download');tmp.write_bytes(b);tmp.replace(p);print('Restored',name,len(b))
